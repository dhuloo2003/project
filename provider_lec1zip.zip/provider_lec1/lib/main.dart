import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:provider/provider.dart';

Future<void> main() async {
  await GetStorage.init();
  runApp(MaterialApp(home: proo(),));

}
class proo extends StatelessWidget {


  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: Text("Provider"),),
      body: ChangeNotifierProvider(create: (context) => model(),
        child: Consumer<model>(builder: (context, value, child) {
          return  Stack(
            children: [
              Center(child: Text("${value.cnt}",style: TextStyle(fontSize: 30),)),
              Positioned(
                  bottom: 20,right: 20,
                  child: IconButton(onPressed: () {
                    value.increment();
              }, icon: Icon(Icons.add_circle,color: Colors.blue,size: 50,)))
            ],
          );
        },),
      ),
    );
  }
}

class model extends ChangeNotifier
{
 int cnt=0;

  void increment() {
    cnt++;
    notifyListeners();
  }

}
