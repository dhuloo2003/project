import 'package:shared_preferences/shared_preferences.dart';

class shar_pref{
  static SharedPreferences? pref;
}