package com.example.provider_lec1;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
