package com.example.googlelogin;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
