import 'dart:convert';

import 'package:api_demo/dio_method.dart';
import 'package:api_demo/post_method_insert.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main(){
  runApp(MaterialApp(home: post_method_insert(),));
}


class demo extends StatefulWidget {
  const demo({Key? key}) : super(key: key);

  @override
  State<demo> createState() => _demoState();
}

class _demoState extends State<demo> {

  List l=[];
  Map m={};
  bool status=false;
  @override
  void initState() {
    super.initState();

    // Basic API calling with get method

    loaddata();

  }

  loaddata() async {
    var url=Uri.parse('https://jsonplaceholder.typicode.com/posts');
    var response = await http.get(url);
    print("Response Statuscode : ${response.statusCode}");
    if(response.statusCode==200){
      print("Response body = ${response.body}");
      l=jsonDecode(response.body);
    }
    status=true;
    setState((){});

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Api Calling"),),
      body: status?(l.length>0?ListView.builder(
        itemCount: l.length,
        itemBuilder: (context, index) {
          m=l[index];
          UserData userdata=UserData.fromJson(m);
          return ListTile(
            leading: Text("${userdata.id}"),
            title: Text("${userdata.title}"),
            subtitle: Text("${userdata.body}"),
          );

      },):Center(child: Text("No Data Fuond"))):Center(child: CircularProgressIndicator()),
    );
  }


}



class UserData {
  int? userId;
  int? id;
  String? title;
  String? body;

  UserData({this.userId, this.id, this.title, this.body});

  UserData.fromJson(Map json) {
    userId = json['userId'];
    id = json['id'];
    title = json['title'];
    body = json['body'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['userId'] = this.userId;
    data['id'] = this.id;
    data['title'] = this.title;
    data['body'] = this.body;
    return data;
  }
}
