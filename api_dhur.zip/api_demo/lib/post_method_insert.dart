import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class post_method_insert extends StatefulWidget {
  const post_method_insert({Key? key}) : super(key: key);

  @override
  State<post_method_insert> createState() => _post_method_insertState();
}

class _post_method_insertState extends State<post_method_insert> {

  TextEditingController tname = TextEditingController();
  TextEditingController tcontact = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Post data in api"),),

      body: Column(
        children: [
          TextField(
            controller: tname,
            decoration: InputDecoration(
              hintText: "Enter full name"
            ),
          ),TextField(
            controller: tcontact,
            maxLength: 10,
            decoration: InputDecoration(
                hintText: "Enter Contact Number"
            ),
          ),
          ElevatedButton(onPressed: () async {
            // Api : https://cdmidevelopment.000webhostapp.com/9to10/insert.php
            // Methos : POST
            // parameters : name, contact

            // success : result = 1, failed : 0

            String name = tname.text;
            String contact = tcontact.text;

            Map map = {'name': name, 'contact': contact};
            var url=Uri.parse('https://cdmidevelopment.000webhostapp.com/9to10/insert.php');
            var response = await http.post(url, body: map);
            print("Response Statuscode = ${response.statusCode }");
            print("${response.body}");

          }, child: Text("Submit Data"))
        ],
      ),

    );
  }
}
