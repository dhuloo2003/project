package com.example.demo_sqflite;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
