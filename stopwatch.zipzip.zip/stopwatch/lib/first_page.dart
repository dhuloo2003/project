import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  int h = 00;
  int m = 00;
  int s = 00;
  int status = 0;
  bool start = true;
  bool pause = true;
  String time = "";
  String lap = "";

  get() async* {
    if (status == 1) {
      while (status==1) {
        await Future.delayed(Duration(seconds: 1));
        s++;
        if (s >= 60) {
          m++;
          s = 00;
        }
        if (m >= 60) {
          h++;
          m = 00;
        }
        time = "${h} : ${m} : ${s}";
        yield time;
      }
    } else if (status == 0) {
      h = 0;
      s = 0;
      m = 0;
      time = "${h}:${m}:${s}";
      yield time;
    } else if (status == 2) {
      time = "${h}:${m}:${s}";
      yield time;
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            "Stopwatch",
            style: TextStyle(color: Colors.black),
          ),
          backgroundColor: Colors.white38,
        ),
        body: StreamBuilder(
          stream: get(),
          builder: (context, snapshot) {
            return SafeArea(
                child: Container(
                  margin: EdgeInsets.all(10),
              color: Colors.black,
              child: Column(
                children: [
                  Expanded(
                      child: Container(
                        margin: EdgeInsets.all(10),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white70),
                    child: Text(
                      "${snapshot.data}",
                      style: TextStyle(fontSize: 30, color: Colors.black),
                    ),
                  )),
                  Container(height: 200,
                    child: SingleChildScrollView(scrollDirection: Axis.vertical,
                        child: Text("${lap}",style: TextStyle(color: Colors.white70),)),
                  ),
                  model(),
                ],
              ),
            ));
          },
        ));
  }

 Expanded model() {
    if (start == true) {
      return Expanded(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            InkWell(
              onTap: () {
                setState(() {
                  start = false;
                  status = 1;
                });
              },
              child: Container(
                height: 60,
                width: 140,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white70,
                  borderRadius: BorderRadius.all(
                    Radius.circular(20),
                  ),
                ),
                child: Text("Start"),
              ),
            ),
          ],
        ),
      );
    } else {
      return Expanded(
          child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          InkWell(
            onTap: () {
              setState(() {
                if (pause == true) {
                  status = 2;
                  pause = false;
                } else {
                  status = 1;
                  pause = true;
                }
              });
            },
            child: Container(
              height: 60,
              width: 140,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white70,
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
              child: Text(pause ? "pause" : "resume"),
            ),
          ),
          InkWell(
            onTap: () {
              setState(() {
                if (pause == true) {
                  lap = lap + "\n" + time;
                } else {
                  status = 0;
                  start = true;
                  pause = true;
                  lap = "";
                }
              });
            },
            child: Container(
              height: 60,
              width: 140,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white70,
                borderRadius: BorderRadius.all(
                  Radius.circular(20),
                ),
              ),
              child: Text(pause ? "lap" : "reset"),
            ),
          ),
        ],
      ));
    }
  }
}
