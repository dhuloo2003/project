import 'package:flutter/material.dart';
import 'package:stopwatch/first_page.dart';

void main()
{
  runApp(MaterialApp(home: first(),));
}