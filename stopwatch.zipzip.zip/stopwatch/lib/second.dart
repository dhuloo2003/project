// StreamBuilder(
// stream: get(),
// builder: (context, snapshot) {
// if (snapshot.connectionState == ConnectionState.waiting) {
// return Center(
// child: Container(
// height: 700,
// width: 500,
// color: Colors.black,
// child: Text("Time :${snapshot.data}"),
// ),
// );
// } else {
// return Center(
// child: CircularProgressIndicator(),
// );
// }
// },
// ));