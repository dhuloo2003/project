import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class viewpage extends StatefulWidget {
  const viewpage({Key? key}) : super(key: key);

  @override
  State<viewpage> createState() => _viewpageState();
}

class _viewpageState extends State<viewpage> {
  List l = [];

  int status = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    loadData();
  }

  loadData() async {
    //API : https://cdmidevelopment.000webhostapp.com/9to10/viewdata.php
    // Method : POST
    // Parameter : id  like 1,2,3,4,....
    // success : result = 1, failed : 0

    // Map map = {'id': "1"};
    // var url = Uri.parse(
    //     'https://cdmidevelopment.000webhostapp.com/9to10/viewdata.php');
    // var response = await http.post(url, body: map);


    var url = Uri.parse(
        'https://cdmidevelopment.000webhostapp.com/9to10/viewdata.php?id=1');
    var response = await http.get(url);

    print('Response status: ${response.statusCode}');
    print(response.body);

    Map m = jsonDecode(response.body);

    int result = m['result'];

    if (result == 1) {
      l = m['data'];
    }
    status = 1;

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ViewData"),
      ),
      body: status == 0
          ? Center(child: CircularProgressIndicator())
          : (l.length > 0
              ? ListView.builder(
                  itemCount: l.length,
                  itemBuilder: (context, index) {
                    Map m = l[index];

                    User user = User.fromJson(m);
                    return ListTile(
                      leading: Text("${user.id}"),
                      title: Text("${user.name}"),
                      subtitle: Text("${user.contact}"),
                    );
                  },
                )
              : Text("No data")),
    );
  }
}

class User {
  String? id;
  String? name;
  String? contact;

  User({this.id, this.name, this.contact});

  User.fromJson(Map json) {
    id = json['id'];
    name = json['name'];
    contact = json['contact'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['contact'] = this.contact;
    return data;
  }
}
