import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class insertpage extends StatefulWidget {
  const insertpage({Key? key}) : super(key: key);

  @override
  State<insertpage> createState() => _insertpageState();
}

class _insertpageState extends State<insertpage> {

  TextEditingController tname = TextEditingController();
  TextEditingController tcontact = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Register"),),
      body: Column(
        children: [
          TextField(controller: tname,),
          TextField(controller: tcontact,),
          ElevatedButton(onPressed: () async {

            String name = tname.text;
            String contact = tcontact.text;

            // Api : https://cdmidevelopment.000webhostapp.com/9to10/insert.php
            // Methos : POST
            // parameters : name, contact

            // success : result = 1, failed : 0

            Map map = {'name': name, 'contact': contact};
            var url = Uri.parse('https://cdmidevelopment.000webhostapp.com/9to10/insert.php');
            var response = await http.post(url, body: map);
            print('Response status: ${response.statusCode}');
            print(response.body);

          }, child: Text("Submit"))
        ],
      ),
    );
  }
}
