package com.example.lec_5_30;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
