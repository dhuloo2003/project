## 0.1.0

* Adds an initial implementation of Windows support for the permission_handler plugin.
