import 'package:carousel_indicator/carousel_indicator.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_carousel_slider/carousel_slider_indicators.dart';
import 'package:flutter_carousel_slider/carousel_slider_transforms.dart';
import 'package:hotstar_design/secondpage.dart';

class homepage extends StatefulWidget {
  const homepage({Key? key}) : super(key: key);

  @override
  State<homepage> createState() => _homepageState();
}

class _homepageState extends State<homepage> {
  List<String> catagories = [
    'Latest & Trending',
    'Popular Movies',
    'Popular Show',
    'Movies Recommended For You',
    'Shows Recommended For You',
    'Multiplex Movies',
    'Best of Foreign Shows Dubbed',
    'Hotstar Specials - Free Episode'
  ];
  String logo = 'hotstarimage/hotstar_logo.jpeg';
  List<String> latest = [
    ('hotstarimage/firstpage/1.jpeg'),
    ('hotstarimage/firstpage/2.jpeg'),
    ('hotstarimage/firstpage/3.jpeg'),
    ('hotstarimage/firstpage/4.jpeg'),
    ('hotstarimage/firstpage/5.jpeg'),
    ('hotstarimage/firstpage/6.jpeg'),
    ('hotstarimage/firstpage/7.jpeg'),
    ('hotstarimage/firstpage/8.jpeg'),
    ('hotstarimage/firstpage/9.jpeg'),
    ('hotstarimage/firstpage/10.jpeg'),
    ('hotstarimage/firstpage/11.jpeg'),
    ('hotstarimage/firstpage/12.jpeg'),
    ('hotstarimage/firstpage/13.jpeg'),
    ('hotstarimage/firstpage/14.jpeg'),
    ('hotstarimage/firstpage/15.jpeg'),
    ('hotstarimage/firstpage/16.webp'),
    ('hotstarimage/firstpage/17.webp'),
    ('hotstarimage/firstpage/18.webp'),
    ('hotstarimage/firstpage/19.webp'),
    ('hotstarimage/firstpage/20.webp'),
    ('hotstarimage/firstpage/21.webp'),
    ('hotstarimage/firstpage/22.webp'),
    ('hotstarimage/firstpage/23.webp'),
    ('hotstarimage/firstpage/24.webp'),
    ('hotstarimage/firstpage/25.webp'),
    ('hotstarimage/firstpage/26.webp'),
    ('hotstarimage/firstpage/27.webp'),
    ('hotstarimage/firstpage/28.webp'),
    ('hotstarimage/firstpage/29.webp'),
    ('hotstarimage/firstpage/30.webp'),
    ('hotstarimage/firstpage/31.webp'),
    ('hotstarimage/firstpage/32.webp'),
    ('hotstarimage/firstpage/33.webp'),
    ('hotstarimage/firstpage/34.webp'),
    ('hotstarimage/firstpage/35.webp'),
    ('hotstarimage/firstpage/36.webp'),
    ('hotstarimage/firstpage/37.webp'),
    ('hotstarimage/firstpage/38.webp'),
    ('hotstarimage/firstpage/39.webp'),
    ('hotstarimage/firstpage/40.webp'),
  ];
  List<String> pop_movie = [
    'hotstarimage/popular movies/1.webp',
    'hotstarimage/popular movies/2.webp',
    'hotstarimage/popular movies/3.webp',
    'hotstarimage/popular movies/4.webp',
    'hotstarimage/popular movies/5.webp',
    'hotstarimage/popular movies/6.webp',
    'hotstarimage/popular movies/7.webp',
    'hotstarimage/popular movies/8.webp',
    'hotstarimage/popular movies/9.webp',
    'hotstarimage/popular movies/10.webp',
    'hotstarimage/popular movies/11.webp',
    'hotstarimage/popular movies/12.webp',
    'hotstarimage/popular movies/13.webp',
    'hotstarimage/popular movies/14.webp',
    'hotstarimage/popular movies/15.webp',
    'hotstarimage/popular movies/16.webp',
    'hotstarimage/popular movies/17.webp',
    'hotstarimage/popular movies/18.webp',
    'hotstarimage/popular movies/19.webp',
    ('hotstarimage/popular movies/20.webp'),
    ('hotstarimage/popular movies/21.webp'),
    ('hotstarimage/popular movies/22.webp'),
    ('hotstarimage/popular movies/23.webp'),
    ('hotstarimage/popular movies/24.webp'),
    ('hotstarimage/popular movies/25.webp'),
    ('hotstarimage/popular movies/26.webp'),
    ('hotstarimage/popular movies/27.webp'),
    ('hotstarimage/popular movies/28.webp'),
    ('hotstarimage/popular movies/29.webp'),
    ('hotstarimage/popular movies/30.webp'),
    ('hotstarimage/popular movies/31.webp'),
    ('hotstarimage/popular movies/32.webp'),
    ('hotstarimage/popular movies/33.webp'),
    ('hotstarimage/popular movies/34.webp'),
    ('hotstarimage/popular movies/35.webp'),
    ('hotstarimage/popular movies/36.webp'),
    ('hotstarimage/popular movies/37.webp'),
    ('hotstarimage/popular movies/38.webp'),
    ('hotstarimage/popular movies/39.webp'),
    ('hotstarimage/popular movies/40.webp'),
  ];
  List<String> pop_show = [
    'hotstarimage/popular/1.webp',
    'hotstarimage/popular/2.webp',
    'hotstarimage/popular/3.webp',
    'hotstarimage/popular/4.webp',
    'hotstarimage/popular/5.webp',
    'hotstarimage/popular/6.webp',
    'hotstarimage/popular/7.webp',
    'hotstarimage/popular/8.webp',
    'hotstarimage/popular/9.webp',
    'hotstarimage/popular/10.webp',
    'hotstarimage/popular/11.webp',
    'hotstarimage/popular/12.webp',
    'hotstarimage/popular/13.webp',
    'hotstarimage/popular/14.webp',
    'hotstarimage/popular/15.webp',
    'hotstarimage/popular/16.webp',
    'hotstarimage/popular/17.webp',
    'hotstarimage/popular/18.webp',
    'hotstarimage/popular/19.webp',
    'hotstarimage/popular/20.webp',
    'hotstarimage/popular/21.webp',
    'hotstarimage/popular/22.webp',
    'hotstarimage/popular/23.webp',
    'hotstarimage/popular/24.webp',
    'hotstarimage/popular/25.webp',
    'hotstarimage/popular/26.webp',
    'hotstarimage/popular/27.webp',
    'hotstarimage/popular/28.webp',
    'hotstarimage/popular/29.webp',
    'hotstarimage/popular/30.webp',
    'hotstarimage/popular/31.webp',
    'hotstarimage/popular/32.webp',
    'hotstarimage/popular/33.webp',
    'hotstarimage/popular/34.webp',
    'hotstarimage/popular/35.webp',
    'hotstarimage/popular/36.webp',
    'hotstarimage/popular/37.webp',
    'hotstarimage/popular/38.webp',
    'hotstarimage/popular/39.webp',
    'hotstarimage/popular/40.webp'
  ];
  List<String> rec_movie = [
    'hotstarimage/recommended movies/1.webp',
    'hotstarimage/recommended movies/2.webp',
    'hotstarimage/recommended movies/3.webp',
    'hotstarimage/recommended movies/4.webp',
    'hotstarimage/recommended movies/5.webp',
    'hotstarimage/recommended movies/6.webp',
    'hotstarimage/recommended movies/7.webp',
    'hotstarimage/recommended movies/8.webp',
    'hotstarimage/recommended movies/9.webp',
    'hotstarimage/recommended movies/10.webp',
    'hotstarimage/recommended movies/11.webp',
    'hotstarimage/recommended movies/12.webp',
    'hotstarimage/recommended movies/13.webp',
    'hotstarimage/recommended movies/14.webp',
    'hotstarimage/recommended movies/15.webp',
    'hotstarimage/recommended movies/16.webp',
    'hotstarimage/recommended movies/17.webp',
    'hotstarimage/recommended movies/18.webp',
    'hotstarimage/recommended movies/19.webp',
    'hotstarimage/recommended movies/20.webp',
    'hotstarimage/recommended movies/21.webp',
    'hotstarimage/recommended movies/22.webp',
    'hotstarimage/recommended movies/23.webp',
    'hotstarimage/recommended movies/24.webp',
    'hotstarimage/recommended movies/25.webp',
    'hotstarimage/recommended movies/26.webp',
    'hotstarimage/recommended movies/27.webp',
    'hotstarimage/recommended movies/28.webp',
    'hotstarimage/recommended movies/29.webp',
    'hotstarimage/recommended movies/30.webp',
    'hotstarimage/recommended movies/31.webp',
    'hotstarimage/recommended movies/32.webp',
    'hotstarimage/recommended movies/33.webp',
    'hotstarimage/recommended movies/34.webp',
    'hotstarimage/recommended movies/35.webp',
    'hotstarimage/recommended movies/36.webp',
    'hotstarimage/recommended movies/37.webp',
    'hotstarimage/recommended movies/38.webp',
    'hotstarimage/recommended movies/39.webp',
    'hotstarimage/recommended movies/40.webp'
  ];
  List<String> mul_movie = [
    'hotstarimage/multiplex_movies/1.webp',
    'hotstarimage/multiplex_movies/2.webp',
    'hotstarimage/multiplex_movies/3.webp',
    'hotstarimage/multiplex_movies/4.webp',
    'hotstarimage/multiplex_movies/5.webp',
    'hotstarimage/multiplex_movies/6.webp',
    'hotstarimage/multiplex_movies/7.webp',
    'hotstarimage/multiplex_movies/8.webp',
    'hotstarimage/multiplex_movies/9.webp',
    'hotstarimage/multiplex_movies/10.webp',
    'hotstarimage/multiplex_movies/11.webp',
    'hotstarimage/multiplex_movies/12.webp',
    'hotstarimage/multiplex_movies/13.webp',
    'hotstarimage/multiplex_movies/14.webp',
    'hotstarimage/multiplex_movies/15.webp',
    'hotstarimage/multiplex_movies/16.webp',
    'hotstarimage/multiplex_movies/17.webp',
    'hotstarimage/multiplex_movies/18.webp',
    'hotstarimage/multiplex_movies/19.webp',
    'hotstarimage/multiplex_movies/20.webp',
    'hotstarimage/multiplex_movies/21.webp',
    'hotstarimage/multiplex_movies/22.webp',
    'hotstarimage/multiplex_movies/23.webp',
    'hotstarimage/multiplex_movies/24.webp',
    'hotstarimage/multiplex_movies/25.webp',
    'hotstarimage/multiplex_movies/26.webp',
    'hotstarimage/multiplex_movies/27.webp',
    'hotstarimage/multiplex_movies/28.webp',
    'hotstarimage/multiplex_movies/29.webp',
    'hotstarimage/multiplex_movies/30.webp',
    'hotstarimage/multiplex_movies/31.webp',
    'hotstarimage/multiplex_movies/32.webp',
    'hotstarimage/multiplex_movies/33.webp',
    'hotstarimage/multiplex_movies/34.webp',
    'hotstarimage/multiplex_movies/35.webp',
    'hotstarimage/multiplex_movies/36.webp',
    'hotstarimage/multiplex_movies/37.webp',
    'hotstarimage/multiplex_movies/38.webp',
    'hotstarimage/multiplex_movies/39.webp',
    'hotstarimage/multiplex_movies/40.webp'
  ];
  List<String> rec_show = [
    'hotstarimage/recommended shows/1.webp',
    'hotstarimage/recommended shows/2.webp',
    'hotstarimage/recommended shows/3.webp',
    'hotstarimage/recommended shows/4.webp',
    'hotstarimage/recommended shows/5.webp',
    'hotstarimage/recommended shows/6.webp',
    'hotstarimage/recommended shows/7.webp',
    'hotstarimage/recommended shows/8.webp',
    'hotstarimage/recommended shows/9.webp',
    'hotstarimage/recommended shows/10.webp',
    'hotstarimage/recommended shows/11.webp',
    'hotstarimage/recommended shows/12.webp',
    'hotstarimage/recommended shows/13.webp',
    'hotstarimage/recommended shows/14.webp',
    'hotstarimage/recommended shows/15.webp',
    'hotstarimage/recommended shows/16.webp',
    'hotstarimage/recommended shows/17.webp',
    'hotstarimage/recommended shows/18.webp',
    'hotstarimage/recommended shows/19.webp',
    'hotstarimage/recommended shows/20.webp',
    'hotstarimage/recommended shows/21.webp',
    'hotstarimage/recommended shows/22.webp',
    'hotstarimage/recommended shows/23.webp',
    'hotstarimage/recommended shows/24.webp',
    'hotstarimage/recommended shows/25.webp',
    'hotstarimage/recommended shows/26.webp',
    'hotstarimage/recommended shows/27.webp',
    'hotstarimage/recommended shows/28.webp',
    'hotstarimage/recommended shows/29.webp',
    'hotstarimage/recommended shows/30.webp',
    'hotstarimage/recommended shows/31.webp',
    'hotstarimage/recommended shows/32.webp',
    'hotstarimage/recommended shows/33.webp',
    'hotstarimage/recommended shows/34.webp',
    'hotstarimage/recommended shows/35.webp',
    'hotstarimage/recommended shows/36.webp',
    'hotstarimage/recommended shows/37.webp',
    'hotstarimage/recommended shows/38.webp',
    'hotstarimage/recommended shows/39.webp',
    'hotstarimage/recommended shows/40.webp'
  ];
  List<String> foreign_show = [
    'hotstarimage/foreign_shows_dubbed/1.webp',
    'hotstarimage/foreign_shows_dubbed/2.webp',
    'hotstarimage/foreign_shows_dubbed/3.webp',
    'hotstarimage/foreign_shows_dubbed/4.webp',
    'hotstarimage/foreign_shows_dubbed/5.webp',
  ];
  List<String> hot_spec = [
    'hotstarimage/hotstar_special/1.webp',
    'hotstarimage/hotstar_special/2.webp',
    'hotstarimage/hotstar_special/3.webp',
    'hotstarimage/hotstar_special/4.webp',
    'hotstarimage/hotstar_special/5.webp',
    'hotstarimage/hotstar_special/6.webp',
    'hotstarimage/hotstar_special/7.webp',
    'hotstarimage/hotstar_special/8.webp',
    'hotstarimage/hotstar_special/9.webp',
    'hotstarimage/hotstar_special/10.webp',
    'hotstarimage/hotstar_special/11.webp',
    'hotstarimage/hotstar_special/12.webp',
    'hotstarimage/hotstar_special/13.webp',
  ];
  List<String> slids=['1.webp','2.webp','3.webp','4.webp','5.webp',];
  GlobalKey<CarouselSliderState> _sliderKey = GlobalKey();
  BoxDecoration deco() {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(10),
    );
  }
  List<String> drawerList=['Log in','KiDS SAFE','Download','Watchlist','Prizes','Channel','Language','Genres','Preference','Help'];
  List<Icon> iconlist=[Icon(Icons.login),Icon(Icons.cloud_download_rounded),
    Icon(Icons.watch_later),
    Icon(Icons.card_giftcard),

  ];
  int selindex=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black,
title: Image.asset("$logo",
    height: 50, width: 200, fit: BoxFit.fill),
      ),
      drawer: Drawer(
        width: 200,

      ),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (value) {
          selindex=value;
          setState((){});
        },
        items: [
        BottomNavigationBarItem(icon: Icon(Icons.home,),backgroundColor: Colors.black,label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.live_tv_rounded,),label: "TV"),
        BottomNavigationBarItem(icon: Icon(Icons.home,),backgroundColor: Colors.black,label: "Diseny",),
        BottomNavigationBarItem(icon: Icon(Icons.movie_rounded,),backgroundColor: Colors.black,label: "Movies"),
        BottomNavigationBarItem(icon: Icon(Icons.sports_cricket_rounded,),backgroundColor: Colors.black,label: "Sports"),
      ],
        backgroundColor: Colors.transparent,selectedItemColor: Colors.redAccent,
        currentIndex: selindex,
      ),
      body: SafeArea(
        child:
          ListView(padding: EdgeInsets.only(top: 50),
            children: [


              Column(
                children: [
                  firsttitle(0),
                  Container(
                      height: 200,
                      child: GridView.builder(
                        padding: EdgeInsets.all(5),
                        itemCount: latest.length,scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            height: 200,
                            padding: EdgeInsets.all(7),
                            width: 140,
                            decoration: deco(),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  "${latest[index]}",
                                  fit: BoxFit.fill,
                                )),
                          );
                        },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1,childAspectRatio: 1.25,mainAxisSpacing: 5), )
                  )
                ],
              ),
              Expanded(
                child: Container(   padding: EdgeInsets.only(top: 20,bottom: 20),
                  child: CarouselSlider.builder(key: _sliderKey,
                    options:CarouselOptions(
                        enlargeCenterPage: true,
                        autoPlay: true,
                        aspectRatio: 2/1,
                        scrollDirection: Axis.horizontal,
                        autoPlayAnimationDuration: Duration(milliseconds: 200)
                    ),
                    itemCount: slids.length,
                    itemBuilder: (context, index, realIndex) {
                      return Container(
                        padding: EdgeInsets.only(left: 0,right: 0),
                        decoration: deco(),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: Image.asset(
                            "hotstarimage/slid/${slids[index]}",
                            fit: BoxFit.fill,
                          ),),
                      );
                    },
                  ),
                ),
              ),
              Column(
                children: [
                  firsttitle(1),
                  Container(
                      height: 200,
                      child: GridView.builder(
                        padding: EdgeInsets.all(5),
                        itemCount: pop_movie.length,scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            height: 200,
                            padding: EdgeInsets.all(7),
                            width: 140,
                            decoration: deco(),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  "${pop_movie[index]}",
                                  fit: BoxFit.fill,
                                )),
                          );
                        },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1,childAspectRatio: 1.25,mainAxisSpacing: 5), )
                  )
                ],
              ),
              Column(
                children: [
                  firsttitle(2),
                  Container(
                      height: 200,
                      child: GridView.builder(
                        padding: EdgeInsets.all(5),
                        itemCount: pop_show.length,scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            height: 200,
                            padding: EdgeInsets.all(7),
                            width: 140,
                            decoration: deco(),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  "${pop_show[index]}",
                                  fit: BoxFit.fill,
                                )),
                          );
                        },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1,childAspectRatio: 1.25,mainAxisSpacing: 5), )
                  )
                ],
              ),
              Column(
                children: [
                  firsttitle(3),
                  Container(
                      height: 200,
                      child: GridView.builder(
                        padding: EdgeInsets.all(5),
                        itemCount: rec_movie.length,scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            height: 200,
                            padding: EdgeInsets.all(7),
                            width: 140,
                            decoration: deco(),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  "${rec_movie[index]}",
                                  fit: BoxFit.fill,
                                )),
                          );
                        },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1,childAspectRatio: 1.25,mainAxisSpacing: 5), )
                  )
                ],
              ),
              Column(
                children: [
                  firsttitle(4),
                  Container(
                      height: 200,
                      child: GridView.builder(
                        padding: EdgeInsets.all(5),
                        itemCount: rec_show.length,scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            height: 200,
                            padding: EdgeInsets.all(7),
                            width: 140,
                            decoration: deco(),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  "${rec_show[index]}",
                                  fit: BoxFit.fill,
                                )),
                          );
                        },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1,childAspectRatio: 1.25,mainAxisSpacing: 5), )
                  )
                ],
              ),
              Column(
                children: [
                  firsttitle(5),
                  Container(
                      height: 200,
                      child: GridView.builder(
                        padding: EdgeInsets.all(5),
                        itemCount: mul_movie.length,scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            height: 200,
                            padding: EdgeInsets.all(7),
                            width: 140,
                            decoration: deco(),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  "${mul_movie[index]}",
                                  fit: BoxFit.fill,
                                )),
                          );
                        },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1,childAspectRatio: 1.25,mainAxisSpacing: 5), )
                  )
                ],
              ),
              Column(
                children: [
                  firsttitle(6),
                  Container(
                      height: 200,
                      child: GridView.builder(
                        padding: EdgeInsets.all(5),
                        itemCount: foreign_show.length,scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            height: 200,
                            padding: EdgeInsets.all(7),
                            width: 140,
                            decoration: deco(),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  "${foreign_show[index]}",
                                  fit: BoxFit.fill,
                                )),
                          );
                        },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1,childAspectRatio: 1.25,mainAxisSpacing: 5), )
                  )
                ],
              ),
              Column(
                children: [
                  firsttitle(7),
                  Container(
                      height: 200,
                      child: GridView.builder(
                        padding: EdgeInsets.all(5),
                        itemCount: hot_spec.length,scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            height: 200,
                            padding: EdgeInsets.all(7),
                            width: 140,
                            decoration: deco(),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.asset(
                                  "${hot_spec[index]}",
                                  fit: BoxFit.fill,
                                )),
                          );
                        },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1,childAspectRatio: 1.25,mainAxisSpacing: 5), )
                  )
                ],
              ),
            ],
          ),
      ),
    );
  }

  firsttitle(int k) {
    return InkWell(
      hoverColor: Colors.orange.withOpacity(0.2),
      onTap: () {
        if (k == 0) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return secondpage(catagories, latest, k);
            },
          ));
        } else if (k == 1) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return secondpage(catagories, pop_movie, k);
            },
          ));
        } else if (k == 2) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return secondpage(catagories, pop_show, k);
            },
          ));
        } else if (k == 3) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return secondpage(catagories, rec_movie, k);
            },
          ));
        } else if (k == 4) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return secondpage(catagories, rec_show, k);
            },
          ));
        } else if (k == 5) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return secondpage(catagories, mul_movie, k);
            },
          ));
        } else if (k == 6) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return secondpage(catagories, foreign_show, k);
            },
          ));
        } else if (k == 7) {
          Navigator.push(context, MaterialPageRoute(
            builder: (context) {
              return secondpage(catagories, hot_spec, k);
            },
          ));
        }
      },
      child: Container(
        alignment: Alignment.centerLeft,
        margin: EdgeInsets.only(top: 10, left: 15, bottom: 5),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "${catagories[k]}",
              style: TextStyle(fontSize: 20, color: Colors.white),
            ),
            Container(margin:EdgeInsets.only(right: 10),child: Icon(Icons.arrow_forward_ios,size: 20,color: Colors.white,))
          ],
        ),
      ),
    );
  }
}
