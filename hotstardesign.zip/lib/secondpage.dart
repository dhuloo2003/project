import 'package:flutter/material.dart';

class secondpage extends StatefulWidget {
  List<String> catagories;
  List<String> imag;
  int index;

  secondpage(this.catagories, this.imag, this.index);

  @override
  State<secondpage> createState() => _secondpageState();
}

class _secondpageState extends State<secondpage> {
  List<String> catagories = [];
  List<String> imag = [];
  int index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          title: Text("${widget.catagories[widget.index]}"),
          backgroundColor: Colors.black,),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: GridView.builder(
          padding: EdgeInsets.all(15),
          itemCount: imag.length,
          itemBuilder: (context, index) {
            return Container(
              decoration:
                  BoxDecoration(borderRadius: BorderRadius.circular(10)),
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.asset(
                    "${imag[index]}",
                    fit: BoxFit.fill,
                  )),
            );
          },
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 0.73),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    catagories = widget.catagories;
    imag = widget.imag;
    index = widget.index;
  }
}
