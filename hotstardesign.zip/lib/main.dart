import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter/material.dart';

import 'homepage.dart';

void main() {
  runApp(MaterialApp(
    home: Container(alignment: Alignment.center,
      decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [
                Colors.blue.shade900,
                Colors.blue.shade900,
                Colors.blue.shade800,
                Colors.blue.shade800
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0.2, 0.5, 0.7, 0.9])),
      child: AnimatedSplashScreen(
          backgroundColor: Color.fromARGB(10, 20, 30, 40),
          centered: true,
          splash: Text(
            "hotstar",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 32,
            ),
          ),
          duration: 2000,
          splashTransition: SplashTransition.fadeTransition,
          nextScreen: homepage()),
    ),
  ));
}
