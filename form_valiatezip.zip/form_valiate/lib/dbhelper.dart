import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class dbhelper{
  Future<Database> createDatabase() async {
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'login.db');
    Database database = await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
          // When creating the db, create the table
          await db.execute(
              'CREATE TABLE form (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, contact TEXT, password TEXT, cpassword TEXT, birth TEXT, gender TEXT, hobby TEXT )');
        });
    return database;
  }
}