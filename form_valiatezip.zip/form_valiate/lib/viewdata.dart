import 'package:flutter/material.dart';
import 'package:form_valiate/dbhelper.dart';
import 'package:sqflite/sqflite.dart';

import 'first.dart';

class viewdata extends StatefulWidget {
  String? meth,crick,sing,read,travel;
  viewdata();


  @override
  State<viewdata> createState() => _viewdataState();
}

class _viewdataState extends State<viewdata> {
  bool search=false;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: search?AppBar(title: TextField(
        onChanged: (value) {
          s.clear();
          if(value.isEmpty){
            s.addAll(l);
          }
          else{
            for(int i=0;i<l.length;i++){
              if((l[i]['name'].toString().toLowerCase().contains(value.toLowerCase())
                  ||l[i]['contact'].toString().contains(value.toString()))){
                s.add(l[i]);
              }
            }
          }
          setState((){});
        },
        decoration: InputDecoration(
        border: UnderlineInputBorder(),
        fillColor: Colors.red
      ),
        autofocus: true,
      ),actions: [IconButton(onPressed: () {
        search=false;
        s.clear();
        setState((){});

      }, icon: Icon(Icons.clear))],
      ):AppBar(title: Text("All Data"),actions: [IconButton(onPressed: () {
        search=true;
        s.addAll(l);
        setState((){});
      }, icon: Icon(Icons.search))],
      ),
      body: Stack(
        children: [status?
        (search?
        (s.length>0?
      (ListView.builder(
      itemCount: s.length,
        itemBuilder: (context, index) {
          Map m=s[index];
          return InkWell(
            onLongPress: () {
              showDialog(builder: (context) {
                return AlertDialog(
                  title: Text("Are you sure you want to delete"),
                  actions: [
                    FlatButton(onPressed: () async{
                      s.remove(index);
                      String qry='delete from form where id=${m['id']}';
                      int del=await db!.rawDelete(qry);
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                        return viewdata();
                      },));
                      setState((){});
                    }, child: Text("YES")),
                    FlatButton(onPressed: () {
                      Navigator.pop(context);
                    }, child: Text("NO"))
                  ],
                );
              },context: context, );
            },
            child: ListTile(
              leading: Text("${m['id']}"),
              title: Text("${m['name']} \n ${m['email']} \n ${m['contact']} \n ${m['password']} \n ${m['cpassword']}"
                  "\n ${m['birth']} \n ${m['gender']} \n ${m['hobby']}"),
              trailing: IconButton(onPressed: () {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                  return first("Update",map: m);
                },));
              }, icon: Icon(Icons.edit_off)),
            ),
          );
        },)):Center(child: CircularProgressIndicator())

        ):(l.length>0?(ListView.builder(
          itemCount: l.length,
          itemBuilder: (context, index) {
            Map m=l[index];
            return InkWell(
              onLongPress: () {
                showDialog(builder: (context) {
                  return AlertDialog(
                    title: Text("Are you sure you want to delete"),
                    actions: [
                      FlatButton(onPressed: () async{
                        l.remove(index);
                        String qry='delete from form where id=${m['id']}';
                        int del=await db!.rawDelete(qry);
                        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                          return viewdata();
                        },));
                        setState((){});
                      }, child: Text("YES")),
                      FlatButton(onPressed: () {
                        Navigator.pop(context);
                      }, child: Text("NO"))
                    ],
                  );
                },context: context, );
              },
              child: ListTile(
                leading: Text("${m['id']}"),
                title: Text("${m['name']} \n ${m['email']} \n ${m['contact']} \n ${m['password']} \n ${m['cpassword']}"
                    "\n ${m['birth']} \n ${m['gender']} \n ${m['hobby']}"),
                trailing: IconButton(onPressed: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                    return first("Update",map: m);
                  },));
                }, icon: Icon(Icons.edit_off)),
              ),
            );
          },)):Center(child: CircularProgressIndicator()))
        ):Center(child: CircularProgressIndicator()),
        Positioned(
            bottom: 20,
            right: 20,
            child: IconButton(onPressed: () {
          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
            return first("Insert");
          },));
        }, icon: Icon(Icons.add,color: Colors.blue,size: 50,)))],
      )
    );
  }
List<Map<String, Object?>> l=List.empty(growable: true);
  List<Map<String, Object?>> s=List.empty(growable: true);
  String crick="",sing="",read="",travel="";
  List<String> hob=[];
  bool status=false;
  Database? db;
  @override
  void initState() {
    super.initState();
    getdata();

  }
  getdata() async {
    db=await dbhelper().createDatabase();
    String qry="select * from form";
    List<Map<String, Object?>> x=await db!.rawQuery(qry);
    l.addAll(x);
    l.sort((a, b) => a['name'].toString().compareTo(b['name'].toString()),);
    status=true;
    setState((){});

  }
}
