// ignore_for_file: dead_code

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:form_valiate/dbhelper.dart';
import 'package:form_valiate/viewdata.dart';
import 'package:sqflite/sqflite.dart';

class first extends StatefulWidget {
  String method;
  Map? map;
  first( this.method, {this.map});



  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  bool validate1 = false;
  bool validate2 = false;
  bool validate3 = false;
  bool validate4 = false;
  bool validate5 = false;
  bool validate6 = false;

  String v1 = "";
  String v2 = "";
  String v3 = "";
  String v4 = "";
  String v5 = "";
  String v6 = "";
  bool secure = true;
  bool cricket=false,singing=false,reading=false,travelling=false;
  String crick="",sing="",read="",travel="";

  TextEditingController t1 = TextEditingController();
  TextEditingController t2 = TextEditingController();
  TextEditingController t3 = TextEditingController();
  TextEditingController t4 = TextEditingController();
  TextEditingController t5 = TextEditingController();
  TextEditingController t6 = TextEditingController();

  String male = 'Male';
  String female = 'Female';
  String grpvalue = 'Male';
  String Error="";
  String date_of_birth = "";
  List<String> hob=[];
  // List<Map<String, Object?>> lhob=[];
  Database? db;
  @override
  void initState() {
    super.initState();
    if(widget.method=="Update"){
      t1.text=widget.map!['name'];
      t2.text=widget.map!['email'];
      t3.text=widget.map!['contact'];
      t4.text=widget.map!['password'];
      t5.text=widget.map!['cpassword'];
      t6.text=widget.map!['birth'];
     grpvalue=widget.map!['gender'];
print(widget.map!['hobby']);
     hob.add(widget.map!['hobby']);
     String lhob=widget.map!['hobby'];
     print(lhob);
     print(hob);

    }
    dbhelper().createDatabase().then((value) {
      db=value;
    });
  }
String ss="";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Form"),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(children: [
          Row(
            children: [
              Expanded(flex: 2, child: Text("Full Name :")),
              Expanded(
                flex: 5,
                child: TextField(
                  obscureText: false,
                  controller: t1,
                  keyboardType: TextInputType.text,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                      hintTextDirection: TextDirection.ltr,
                      hintText: "Enter Full Name",
                      errorText: (validate1) ? "$v1" : null,
                      border: OutlineInputBorder()),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(flex: 2, child: Text("Email ID :")),
              Expanded(
                flex: 5,
                child: TextField(
                  controller: t2,
                  keyboardType: TextInputType.emailAddress,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                      hintTextDirection: TextDirection.ltr,
                      hintText: "Enter Email ID",
                      errorText: (validate2) ? "$v2" : null,
                      border: OutlineInputBorder()),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(flex: 2, child: Text("Contact Number : ")),
              Expanded(
                flex: 5,
                child: TextField(
                  controller: t3,
                  maxLength: 10,
                  keyboardType: TextInputType.number,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                      hintText: "Enter Contact Number : ",
                      hintTextDirection: TextDirection.ltr,
                      errorText: (validate3) ? "$v3" : null,
                      border: OutlineInputBorder()),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(flex: 2, child: Text(" Password : ")),
              Expanded(
                flex: 5,
                child: TextField(
                  controller: t4,
                  obscureText: secure,
                  keyboardType: TextInputType.text,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                      suffixIcon: IconButton(
                        onPressed: () {
                          setState(() {
                            if (secure == true) {
                              secure = false;
                            } else {
                              secure = true;
                            }
                          });
                        },
                        icon: Icon(secure
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined),
                      ),
                      hintText: "Enter Enter Password Number : ",
                      hintTextDirection: TextDirection.ltr,
                      errorText: (validate4) ? "$v4" : null,
                      border: OutlineInputBorder()),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(flex: 2, child: Text("Confirm Password : ")),
              Expanded(
                flex: 5,
                child: TextField(
                  controller: t5,
                  obscureText: true,
                  keyboardType: TextInputType.text,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                      hintText: "Enter Confirm Password : ",
                      hintTextDirection: TextDirection.ltr,
                      errorText: (validate5) ? "$v5" : null,
                      border: OutlineInputBorder()),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(flex: 2, child: Text("Gender")),
              Expanded(
                flex: 5,
                child: Container(
                  child: Row(
                    children: [
                      Expanded(
                        child: RadioListTile(
                          title: Text("Male"),
                          onChanged: (value) {
                            setState(() {
                              grpvalue = value as String;
                            });
                          },
                          value: male,
                          groupValue: grpvalue,
                        ),
                      ),
                      Expanded(
                        child: RadioListTile(
                          title: Text("Female"),
                          onChanged: (value) {
                            setState(() {
                              grpvalue = value as String;
                            });
                          },
                          value: female,
                          groupValue: grpvalue,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(flex:2,child: Text("Hobby : ")),
              Expanded(flex: 5,
                child: Container(height: 250,
                  child: Column(
                    children: [
                      CheckboxListTile(
                        onChanged: (value) {
                          setState(() {
                            cricket = value!;
                            if(cricket){
                              crick="Cricket";
                            }else{
                              crick="";
                            }
                          });
                        },
                        value: cricket,
                        title: Text("Cricket"),
                      ),
                      CheckboxListTile(
                        onChanged: (value) {
                          setState(() {
                            singing = value!;
                            if(singing){
                              sing="Singing";
                            }else{
                              sing="";
                            }
                          });
                        },
                        value: singing,
                        title: Text(
                          "Singing",
                        ),
                      ),
                      CheckboxListTile(
                        onChanged: (value) {
                          setState(() {
                            reading = value!;
                            if(reading){
                              read="Reading";
                            }else{
                              read="";
                            }
                          });
                        },
                        value: reading,
                        title: Text("Reading"),
                      ),
                      CheckboxListTile(
                        onChanged: (value) {
                          setState(() {
                            travelling = value!;
                            if(travelling){
                              travel="Travelling";
                            }else{
                              travel="";
                            }
                          });
                        },
                        value: travelling,
                        title: Text("Travelling"),
                      ),
                      Row(
                        children: [
                          Text("$Error",style: TextStyle(color: Colors.red),),
                        ],
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
          Row(
            children: [
              Expanded(flex: 2, child: Text("Date Of Birth : ")),
              Expanded(
                flex: 5,
                child: TextField(
                  controller: t6,
                  keyboardType: TextInputType.number,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                    suffixIcon: IconButton(onPressed: () {
                      showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(1990),
                          lastDate: DateTime(2025))
                          .then(
                            (value) {
                          setState(() {
                            date_of_birth =
                            "${value!.day}/${value.month}/${value
                                .year}";
                            t6.text = date_of_birth;
                          });
                        },
                      );
                    }, icon: Icon(Icons.calendar_month)),
                      hintText: "dd/mm/yy ",
                      hintTextDirection: TextDirection.ltr,
                      errorText: (validate6) ? "$v6" : null,
                      border: OutlineInputBorder()),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                    onPressed: () async {
                      setState(() {
                        //t1
                        if (t1.text.isEmpty) {
                          validate1 = true;
                          v1 = "Please Enter Number";
                        } else {
                          validate1 = false;
                          v1 = "";
                        }

                        //t2
                        String ss = t2.text;
                        int k = 0;
                        for (int i = 0; i < ss.length; i++) {
                          if (ss[i] == '@') {
                            k = i;
                          }
                        }
                        if (t2.text.isEmpty) {
                          validate2 = true;
                          v2 = "Please Enter Email Address";
                        } else if (t2.text.substring(k, ss.length) !=
                                "@gmail.com" &&
                            t2.text.isNotEmpty) {
                          validate2 = true;
                          v2 = "Please valid email address";
                        } else {
                          v2 = "";
                          validate2 = false;
                        }

                        //t3
                        if (t3.text.isEmpty) {
                          validate3 = true;
                          v3 = "Please Enter Number";
                        } else {
                          v3 = "";
                          validate3 = false;
                        }
                        if (t3.text.length < 10) {
                          validate3 = true;
                          v3 = "Please Enter atleast 10 Digit";
                        } else {
                          v3 = "";
                          validate3 = false;
                        }


                      //t4
                      if (t4.text.isNotEmpty && t4.text.length < 6) {
                        v4 = "Enter minmum 5 charactor";
                        validate4 = true;
                      } else if (t4.text.isEmpty) {
                        v4 = "Please Enter Password";
                        validate4 = true;
                      } else {
                        validate4 = false;
                      }
                      //t5
                      if (t5.text.isEmpty) {
                        v5 = "Please Enter Password";
                        validate5 = true;
                      } else if (t5.text.isNotEmpty && t5.text != t4.text) {
                        v5 = "Password does not match";
                        validate5 = true;
                      } else {
                        v5 = "";
                        validate5 = false;
                      }

                      if(cricket || reading || singing || travelling){
                        Error="";
                      }
                      else{
                        Error="Please Select atleast one hobby";
                      }

                      if(t6.text.isEmpty){
                        v6="please enter birth date";
                        validate6=true;
                      }
                      else{
                        v6="";
                        validate6=false;
                      }

                      });
                      hob=List.empty(growable: true);
                      if(cricket){
                        hob.add("Cricket");
                      }if(singing){
                        hob.add("Singing");
                      }if(reading){
                        hob.add("Reading");
                      }if(travelling){
                        hob.add("Travelling");
                      }

                      if(widget.method=="Insert"){
                        if(t1.text.isNotEmpty && t2.text.isNotEmpty && t3.text.isNotEmpty && t4.text.isNotEmpty &&
                            t5.text.isNotEmpty && t6.text.isNotEmpty &&(cricket||singing||reading||travelling)){
                          String name=t1.text;
                          String email=t2.text;
                          String contact=t3.text;
                          String password=t4.text;
                          String cpassword=t5.text;
                          String birth=t6.text;
                          String gender=grpvalue;
                          print("$hob $name $email $contact $password $cpassword $birth $gender");

                          String qry='INSERT INTO form(name, email, contact, password, cpassword, birth, gender, hobby) '
                              'VALUES("$name","$email","$contact","$password","$cpassword","$birth","$gender","$hob")';
                          int id1 = await db!.rawInsert(qry);
                          print(id1);

                          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                            return viewdata();
                          },));

                        }
                      }else{
                        if(t1.text.isNotEmpty && t2.text.isNotEmpty && t3.text.isNotEmpty && t4.text.isNotEmpty &&
                            t5.text.isNotEmpty && t6.text.isNotEmpty && (cricket||singing||reading||travelling)){
                          String name=t1.text;
                          String email=t2.text;
                          String contact=t3.text;
                          String password=t4.text;
                          String cpassword=t5.text;
                          String birth=t6.text;
                          String gender=grpvalue;
                          print("$hob $name $email $contact $password $cpassword $birth $gender");

                          String qry='update form set name="$name", email="$email", contact="$contact", password="$password",'
                              ' cpassword="$cpassword", birth="$birth", gender="$gender", hobby="$hob" where id=${widget.map!['id']}';

                          int upd=await db!.rawUpdate(qry);
                          print(upd);

                          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                            return viewdata();
                          },));

                        }
                      }

                      setState(() {});
                    },
                    child: Text(
                      "Submit",
                      style: TextStyle(fontSize: 24),
                    )),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(child: ElevatedButton(onPressed: () {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                  return viewdata();
                },));
              }, child: Text("View Data")))
            ],
          )
        ]),
      ),
    );
  }
}
