package com.example.form_valiate;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
