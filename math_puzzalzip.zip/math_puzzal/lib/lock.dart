import 'package:flutter/material.dart';
import 'package:math_puzzal/second_page.dart';

class lock extends StatefulWidget {
  const lock({Key? key}) : super(key: key);

  @override
  State<lock> createState() => _lockState();
}

class _lockState extends State<lock> {
  List<int> islock = List.filled(75, 0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
        child: Container(
      decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("my_image/background.jpg"),
                fit: BoxFit.fill)),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 50,
                  alignment: Alignment.center,
                  child: Text(
                    "Selected Puzzle 1",
                    style: TextStyle(fontSize: 16, color: Colors.blue.shade700),
                  ),
                )
              ],
            ),
            Expanded(
                child: Container(
                    width: double.infinity,
                    child: GridView.builder(itemCount: 24,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            if (islock[index] == 0) {
                              Navigator.pushReplacement(context,
                                  MaterialPageRoute(
                                builder: (context) {
                                  return second(index);
                                },
                              ));
                            }
                          },
                          child: Container(
                            width: 45,
                            height: 45,
                            alignment: Alignment.center,
                            margin: EdgeInsets.all(10),
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: islock[index] == "no"
                                        ? Colors.transparent
                                        : Colors.black),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20)),
                                image: (islock[index] == "no")
                                    ? DecorationImage(
                                        image: AssetImage("my_image/lock.png"))
                                    : (islock[index] == "yes")?DecorationImage(image: AssetImage("my_image/tick.png")):null),
                            child: Text(islock[index]==0?"":"${index+1}",style: TextStyle(fontSize: 40,fontFamily: "f1"),),
                          ),
                        );
                      },
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 4),
                    ))),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Expanded(child: InkWell(
                  onTap: () {

                  },
                  child: Container(height: 60,
                  width: 60,
                  margin: EdgeInsets.all(20),
                  alignment: Alignment.centerRight,
                  child: Image(image: AssetImage("my_image/next.png" )),),
                ))
              ],
            )
          ],
        ),
      )),
    );
  }
}
