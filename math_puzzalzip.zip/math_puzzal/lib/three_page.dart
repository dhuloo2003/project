import 'package:flutter/material.dart';
import 'package:math_puzzal/second_page.dart';

class three extends StatefulWidget {
  int cur_level;
  three(this.cur_level);



  @override
  State<three> createState() => _threeState();
}

class _threeState extends State<three> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: Container(
      decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("my_image/background.jpg"), fit: BoxFit.fill)),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                  child: Container(
                margin: EdgeInsets.only(top: 30),
                height: 50,
                alignment: Alignment.center,
                child: Text("PUZZLE 1 COMPLETED",
                    style: TextStyle(
                        fontSize: 25,
                        fontStyle:FontStyle.italic,
                        color: Colors.blue.shade700)),
              ))
            ],
          ),
          Row(
            children: [
              Expanded(
                  child: Container(
                height: 200,
                width: 200,
                margin: EdgeInsets.only(top: 10),
                alignment: Alignment.topCenter,
                decoration: BoxDecoration(
                    image: DecorationImage(
                  image: AssetImage("my_image/trophy.png"),
                )),
              ))
            ],
          ),

          InkWell(onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return second(widget.cur_level);
            },));
          },
            child: Container(
              height: 50,
              width: 200,
              margin: EdgeInsets.only(top: 10),
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.black26),
                  gradient: LinearGradient(
                      begin: Alignment.bottomLeft,
                      end: Alignment.topRight,
                      colors: [
                        Colors.grey.shade500,
                        Colors.white,
                        Colors.grey.shade500
                      ]),
                  borderRadius: BorderRadius.all(Radius.circular(10))),
              alignment: Alignment.center,
              child: Text("CONTINUE",style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
            ),
          ),
          Container(
            height: 50,
            width: 200,
            margin: EdgeInsets.only(top: 10),
            decoration: BoxDecoration(
                border: Border.all(color: Colors.black26),
                gradient: LinearGradient(
                    begin: Alignment.bottomLeft,
                    end: Alignment.topRight,
                    colors: [
                      Colors.grey.shade500,
                      Colors.white,
                      Colors.grey.shade500
                    ]),
                borderRadius: BorderRadius.all(Radius.circular(10))),
            alignment: Alignment.center,
            child: Text("MAIN MENU",style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
          ),
          Container(
            height: 50,
            width: 200,
            margin: EdgeInsets.only(top: 10),
            decoration: BoxDecoration(
                border: Border.all(color: Colors.black26),
                gradient: LinearGradient(
                    begin: Alignment.bottomLeft,
                    end: Alignment.topRight,
                    colors: [
                      Colors.grey.shade500,
                      Colors.white,
                      Colors.grey.shade500
                    ]),
                borderRadius: BorderRadius.all(Radius.circular(10))),
            alignment: Alignment.center,
            child: Text("BUY PRO",style: TextStyle(fontSize: 20,fontStyle: FontStyle.italic),),
          ),
          Container(
            margin: EdgeInsets.all(10),
            child: Text("SHARE THIS PUZZLE",
                style: TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue.shade700)),
          ),
          Container(
            height: 40,
            width: 40,
            margin: EdgeInsets.all(10),
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
              borderRadius:
              BorderRadius.all(Radius.circular(15)),
              gradient: LinearGradient(
                  begin: Alignment.bottomLeft,
                  end: Alignment.topRight,
                  colors: [
                    Colors.grey,
                    Colors.white,
                    Colors.grey
                  ]),
            ),
            child: Image(
                image: AssetImage("my_image/shareus.png")),
          ),
        ],
      ),
    )));
  }
}
