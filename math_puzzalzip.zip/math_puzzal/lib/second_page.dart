import 'package:flutter/material.dart';
import 'package:math_puzzal/model.dart';
import 'package:math_puzzal/three_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class second extends StatefulWidget {
  int cur_level;

  second(this.cur_level);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  int cur_level = 0;
  bool t = false;
  int cnt = 0;
  int check_cnt = 0;
  String ans = "";
  List<int> list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
  List<String> level_status = List.filled(75, "no");
  SharedPreferences? pref;

  @override
  void initState() {
    super.initState();
    cur_level = widget.cur_level;
    set_pref();
  }

  set_pref() async {
    pref = await SharedPreferences.getInstance();
    cur_level = pref!.getInt("levelno") ?? 0;
    print("cur level $cur_level");
    for (int i = 0; i < level_status.length; i++) {
      level_status[i] = pref!.getString("level_status$i") ?? "no";
    }
    print("level ${level_status.length} $level_status");
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("my_image/gameplaybackground.jpg"),
                  fit: BoxFit.fill)),
          child: Column(
            children: [
              Row(
                children: [
                  ///skip
                  InkWell(
                    onTap: () {
                      setState(() {
                        pref!.setString("levelno$cur_level", "skip");
                        cur_level++;
                        pref!.setInt("levelno", cur_level);
                        Navigator.pushReplacement(context, MaterialPageRoute(
                          builder: (context) {
                            return second(cur_level);
                          },
                        ));
                      });
                    },
                    child: Container(
                      margin: EdgeInsets.only(left: 15),
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("my_image/skip.png"))),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      alignment: Alignment.center,
                      margin: EdgeInsets.all(20),
                      height: 80,
                      width: 80,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                        image: AssetImage(
                          "my_image/level_board.png",
                        ),
                      )),
                      child: Text(
                        "Level ${cur_level + 1}",
                        style: TextStyle(fontSize: 26),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 15),
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                      image: AssetImage(
                        "my_image/hint.png",
                      ),
                    )),
                  ),
                ],
              ),
              Expanded(
                child: Row(
                  children: [
                    Expanded(
                        child: Container(
                      margin: EdgeInsets.all(20),
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image:
                                  AssetImage("my_image/p${cur_level + 1}.png"),
                              fit: BoxFit.fill)),
                    ))
                  ],
                ),
              ),
              Container(
                height: 120,
                margin: EdgeInsets.only(bottom: 30),
                color: Colors.black,
                child: Column(
                  children: [
                    Row(children: [
                      Expanded(
                        child: Container(
                          alignment: Alignment.center,
                          margin: EdgeInsets.only(left: 5, bottom: 20, top: 20),
                          height: 40,
                          width: 150,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10))),
                          child: Text(
                            "${ans}",
                            style: TextStyle(color: Colors.black, fontSize: 20),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          if (ans != "") {
                            setState(() {
                              ans = ans.substring(0, ans.length - 1);
                            });
                          }
                        },
                        child: Container(
                          height: 50,
                          width: 50,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage("my_image/delete.png"),
                                fit: BoxFit.fill),
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () {
                          if (model.answer[cur_level] == int.parse(ans)) {
                            for (int i = 0; i <= cur_level; i++) {
                              pref!.setString("level_status$i", "yes");
                            }
                            cur_level++;
                            pref!.setInt("levelno", cur_level);
                            Navigator.push(context, MaterialPageRoute(
                              builder: (context) {
                                return three(cur_level);
                              },
                            ));
                          }
                        },
                        child: Container(
                          margin: EdgeInsets.only(left: 15),
                          height: 40,
                          width: 100,
                          alignment: Alignment.center,
                          child: Text(
                            "submit",
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          ),
                        ),
                      )
                    ]),
                    Row(
                      children: [
                        Expanded(
                            child: Container(
                                height: 40,
                                child: GridView.builder(
                                  gridDelegate:
                                      SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 10),
                                  scrollDirection: Axis.vertical,
                                  itemCount: list.length,
                                  itemBuilder: (context, index) {
                                    return InkWell(
                                      onTap: () {
                                        ans = ans + list[index].toString();
                                        setState(() {});
                                      },
                                      child: Container(
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                            border:
                                                Border.all(color: Colors.white),
                                            color: Colors.white24,
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(2))),
                                        child: Text(
                                          "${list[index]}",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    );
                                  },
                                )))
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
