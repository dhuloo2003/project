import 'package:flutter/material.dart';
import 'package:math_puzzal/lock.dart';
import 'package:math_puzzal/second_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class first extends StatefulWidget {

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  String curfont = "f1";
  List<String> level_status = [];
  int cur_level = 0;

  SharedPreferences? pref;

  @override
  void initState() {

  }

  get() async {
    pref = await SharedPreferences.getInstance();

    cur_level = pref!.getInt("levelno") ?? 0;
    for(int i=0;i<level_status.length;i++)
    {
      level_status[i] = pref!.getString("level_status$i") ??  "no";
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("my_image/background.jpg"),
                  fit: BoxFit.fill)),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                      child: Container(
                    height: 50,
                    alignment: Alignment.center,
                    child: Text(
                      "Math pazzles",
                      style: TextStyle(fontSize: 30, fontFamily: curfont),
                    ),
                  ))
                ],
              ),
              Expanded(
                  child: Row(
                children: [
                  Expanded(
                      child: Container(
                    margin: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image:
                                AssetImage("my_image/blackboard_main_menu.png"),
                            fit: BoxFit.fill)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(
                              builder: (context) {
                                return second(cur_level);
                              },
                            ));
                          },
                          child: Container(
                            alignment: Alignment.center,
                            margin: EdgeInsets.all(10),
                            child: Text(
                              "CONTINUE",
                              style: TextStyle(
                                  fontSize: 20,
                                  fontFamily: curfont,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        InkWell(onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context) {
                            return lock();
                          },));
                        },
                          child: Container(
                              alignment: Alignment.center,
                              margin: EdgeInsets.all(10),
                              child: Text(
                                "PUZZLES",
                                style: TextStyle(
                                    fontSize: 20,
                                    fontFamily: curfont,
                                    color: Colors.white),
                              )),
                        ),
                        Container(
                            margin: EdgeInsets.all(10),
                            child: Text(
                              "BUY PRO",
                              style: TextStyle(
                                  fontSize: 20,
                                  fontFamily: curfont,
                                  color: Colors.white),
                            )),
                      ],
                    ),
                  ))
                ],
              )),
              Row(
                children: [
                  Container(
                    height: 80,
                    width: 80,
                    margin: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage("my_image/ltlicon.png"))),
                  ),
                  Expanded(
                      child: Container(
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              height: 40,
                              width: 40,
                              margin: EdgeInsets.all(10),
                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.black),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(9)),
                                gradient: LinearGradient(
                                    begin: Alignment.bottomLeft,
                                    end: Alignment.topRight,
                                    colors: [
                                      Colors.grey,
                                      Colors.white,
                                      Colors.grey
                                    ]),
                              ),
                              child: Image(
                                  image: AssetImage("my_image/shareus.png")),
                            ),
                            Container(
                              height: 40,
                              width: 40,
                              margin: EdgeInsets.only(
                                  left: 10, right: 20, top: 10, bottom: 10),
                              padding: EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.black),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(9)),
                                gradient: LinearGradient(
                                    begin: Alignment.bottomLeft,
                                    end: Alignment.topRight,
                                    colors: [
                                      Colors.grey,
                                      Colors.white,
                                      Colors.grey
                                    ]),
                              ),
                              child: Image(
                                  image: AssetImage("my_image/emailus.png")),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              height: 30,
                              alignment: Alignment.center,
                              margin: EdgeInsets.only(
                                  left: 10, right: 20, bottom: 10, top: 10),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Colors.black, width: 2)),
                              child: Text(
                                "Privacy Policy",
                                style: TextStyle(fontSize: 15),
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
