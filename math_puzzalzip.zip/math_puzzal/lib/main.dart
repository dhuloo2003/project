import 'package:flutter/material.dart';
import 'package:math_puzzal/first_page.dart';
import 'package:math_puzzal/second_page.dart';

void main()
{
runApp(MaterialApp(home: first(),));

}