package com.example.math_puzzal;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
