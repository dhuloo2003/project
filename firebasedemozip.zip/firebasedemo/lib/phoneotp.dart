import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';

class phoneotp extends StatefulWidget {
  const phoneotp({Key? key}) : super(key: key);

  @override
  State<phoneotp> createState() => _phoneotpState();
}

class _phoneotpState extends State<phoneotp> {
  TextEditingController number=TextEditingController();
  OtpFieldController sms=OtpFieldController();
  String vid="";
  FirebaseAuth auth = FirebaseAuth.instance;
  bool otpsent=false;
  String piin="";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Phone Authentication"),
      ),
      body: Column(
        children: [
          TextField(
            controller: number,maxLength: 10,
            decoration: InputDecoration(hintText: "Contact Number",
            border: OutlineInputBorder()),
          ),
          ElevatedButton(onPressed: () async {
            otpsent=true;
            setState((){});
            String phone=number.text;
            await auth.verifyPhoneNumber(
              phoneNumber: '+91$phone',
              codeSent: (String verificationId, int? resendToken) async {
                vid=verificationId;

              }, verificationFailed: (FirebaseAuthException error) {  },
              verificationCompleted: (PhoneAuthCredential phoneAuthCredential) {  },
              codeAutoRetrievalTimeout: (String verificationId) {  },
            );

          }, child: Text("Sent OTP")),
          otpsent==true?
          OTPTextField(
            controller:sms ,
            length: 6,
            width: MediaQuery.of(context).size.width,
            fieldWidth: 25,
            style: TextStyle(
                fontSize: 17
            ),
            textFieldAlignment: MainAxisAlignment.spaceAround,
            fieldStyle: FieldStyle.underline,
            onCompleted: (pin) {
              piin=pin;
              print("Completed: " + pin);
            },
          ):Container(),
          otpsent==true?
          ElevatedButton(onPressed: () async {
            PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: vid, smsCode: piin); // Sign the user in (or link) with the credentialz
            await auth.signInWithCredential(credential).then((value) {
              print(value);
              String? number=value.user!.phoneNumber;
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return loginsuccess();
              },));
            });
          }, child: Text("verify otp")):Container(),
        ],
      ),
    );
  }
}


class loginsuccess extends StatefulWidget {
  const loginsuccess({Key? key}) : super(key: key);

  @override
  State<loginsuccess> createState() => _loginsuccessState();
}

class _loginsuccessState extends State<loginsuccess> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Container(child: Text("Login Successfully",style: TextStyle(fontSize: 24),),));
  }
}
