import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class login extends StatefulWidget {
  const login({Key? key}) : super(key: key);

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  TextEditingController name=TextEditingController();
  TextEditingController number=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("FireBase Demo"),),
      body: Column(
        children: [
          TextField(
            controller: name,
            decoration: InputDecoration(border: OutlineInputBorder()),
          ),
          TextField(
            controller: number,
            decoration: InputDecoration(border: OutlineInputBorder()),
          ),
          ElevatedButton(onPressed: () async {
            String nam=name.text;
            String num=number.text;
            try {
              final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
                email: nam,
                password: num,
              );
            } on FirebaseAuthException catch (e) {
              if (e.code == 'weak-password') {
                print('The password provided is too weak.');
              } else if (e.code == 'email-already-in-use') {
                print('The account already exists for that email.');
              }
              else{
                print("Login Successfully");
              }
            } catch (e) {
              print(e);
            }

          }, child: Text("Login"))
        ],
      ),
    );
  }
}
