## 3.0.0

- Version bump

## 2.0.4

- Fixes: sharing in isolated sandboxes like Flatpak

## 2.0.3

- Hotfix on 2.0.2, improved solution.

## 2.0.2

- Fixes: share URL is constructed incorrectly #235

## 2.0.1

- Improve documentation

## 2.0.0

- Migrated to null safety

## 1.1.0

- Transfer to plus-plugins monorepo

## 1.0.0

- Initial Linux support.
