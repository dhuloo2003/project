# Share Plus Linux

[![Flutter Community: share_plus_linux](https://fluttercommunity.dev/_github/header/share_plus_linux)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/share_plus_linux.svg)](https://pub.dev/packages/share_plus_linux)

The Linux implementation of [`share_plus`](https://pub.dev/packages/share_plus).

## Usage

This package is already included as part of the `share_plus` package dependency, and will
be included when using `share_plus` as normal.
