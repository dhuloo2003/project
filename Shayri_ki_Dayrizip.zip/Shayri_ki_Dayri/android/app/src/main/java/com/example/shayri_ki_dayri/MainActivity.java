package com.example.shayri_ki_dayri;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
