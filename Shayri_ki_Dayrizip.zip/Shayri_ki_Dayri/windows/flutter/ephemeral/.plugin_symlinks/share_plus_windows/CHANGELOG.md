## 3.0.1

- Update dependencies
- Fix analyzer warnings
- Update `urlLauncher` and replace deprecated `launch` calls

## 3.0.0

- Bump dependencies

## 2.0.3

- Hotfix on 2.0.2, improved solution.

## 2.0.2

- Fixes: share URL is constructed incorrectly #235

## 2.0.1

- Improve documentation

## 2.0.0

- Migrated to null safety

## 0.1.0

- Transfer to plus-plugins monorepo

## 0.0.1

- Initial Windows support.
