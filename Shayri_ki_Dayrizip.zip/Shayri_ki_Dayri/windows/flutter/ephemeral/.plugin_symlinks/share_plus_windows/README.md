# Share Plus Windows

[![Flutter Community: share_plus_windows](https://fluttercommunity.dev/_github/header/share_plus_windows)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/share_plus_windows.svg)](https://pub.dev/packages/share_plus_windows)

The Windows implementation of [`share_plus`](https://pub.dev/packages/share_plus).

## Usage

This package is already included as part of the `share_plus` package dependency, and will
be included when using `share_plus` as normal.
