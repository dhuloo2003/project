class list {
  List<String> love = [
    """Mujhey Nahin Chahiye Badi Badi Khushiyan,
Tumse Bat Ho Jaye To Sari Duniya Ki
Khushi Mere Qadmon Me Hoti Hai.""",
    """Meri Zindagi Ki Khuli Kitaab Ho Tum, 
Mere Jeene Ka Ehsaas Ho Tum, 
Mere Liye Ek Pyara Sa Gulaab Ho Tum""",
    """Muskurate Hain Lab Aakhon Me Nami Hai,
Sab Kuchh Hai Mere Pas, Bus Aik Aapki Kami Hai.""",
    """Mat Rootha Karo Mujhse, Anpadh Sa Hun ,
Tere Siva Kuchh Nahin Aata.""",
    """Pahli Mohabbat Ke Liye Dil Jise Chunata Hai,
Wo Apna Ho ya Na Ho Dil Par Raaj Hamesha Usi Ka Rahta Hai.""",
    """Too Meri Jaroorat Hai,
Too Meri Aadat Hai,
Meri To Bus Yahi Chahat Hai,
Pkar Ke Tera Nam Bol Dun,
Too Meri Mohabbat Hai.""",
    """Koi Kehta Hai Pyar Nasha Ban Jata Hai,
Koi Kahta Hai Pyar Sza Ban Jata Hai,
Par Pyr Karo Agar Sache Dil Se To Wo,
Pyar He Jeene Ki Wajah Ban Jata Hai.""",
    """Apna Banakr Hamen Apni Aagosh Me Bhar Lo,
Hongey Nahin Kabhi Juda Ham Aaj Ye Wda Kar Lo,
Bikhar Jayengey Tumse Door Jo Ho Gaye,
Kal Ho Ya Na Ho Sake Aj Chand Baten Krlo.""",
    """suno na wo jo lakhon me ek hota,
hai na mere liye bas wo hi ho tum.""",
    """Baby baten to roj karte hai,
chalo aaj romance karte hai.."""
  ];

  List<String> sad = [
    """Dukh Is Baat Ka Nahin, Ki Tum Meri Na Hui. 
Dukh Is Baat Ka Hai, Ki Tum Yaadon Se Na Gayi.""",
    """Tere Badalne Ka Dukh Nahin Hai Mujhko
Main To Apne Yaqeen Par Sharminda Hun.""",
    """Kitna Pagal Hai Ye Dil Kaise Samjaoun Isey,
Ki Jisey Too Khona Nahin Chahta 
Wo Tera Hona Nahin Chahta.""",
    """Bahot Dard Deti Hain Teri Yaden
So Jaoun To Jaga Deti Hain
Jag Jaoun To Rula Deti Hain.""",
    """Meri Wafa Ki Kadar Na Kee Apani Pasand Pe Aitbaar Kiya Hota
Suna Hai Vo Unaki Bhi Na Huee Mujhe Chhod Diya Tha To Use Apana Liya Hota""",
    """Muddaton Baad Bhi Nahi Milte Hum Jaise Nayab Log
Tere Haath Kiya Lag Gaye Tumne To Hamhe Aam Samjh Liya""",
    """Inhe Apna Bhi Nahi Sakta Magat Itna Kya Kam Hai
Kuch Muddatein Haseen Khwabon Main Kho Kar Ji Liya Humne""",
    """Duba Hai Mera Badan Mere Hi Khoon Se
Ye Kanch Ke Tukdo Pe Bharose Ki Saza Hai""",
    """I Know I Can't 
Live Without Him.
And There Is The 
Same Case With Him, 
But For Someone Else.""",
    """Suni Thi Humne Gajlo Me Judai Ki Baatein
Ab Khud Pe Beeti To Haqiqat Ka Andaza Hua"""
  ];

  List<String> romantic = [
    """Tumhaara To Gussa Bhi 
Itna Pyara Lagta Hai Ki 
Dil Karta Hai Din Bhar 
Tumhen Hi Tang Karte Rahen.""",
    """Itna Pyar To Maine Khud 
Se Bhi Nahin Kiya Jitna 
Tumse Ho Gaya Hai.""",
    """Agar Milatee Mujhe Do 
Din Kee Baadashaahee. 
To Meree Riyaasat Mein Teree 
Tasveer Ke Sikke Chalate""",
    """Mere Wajood Me Kaash
Too Utar Jaye. 
Main Dekhu Aaina Aur 
Too Nazar Aaye.""",
    """Na Tumhen Hosh Rahe Na Mujhe Hosh Rahe, 
Is Tarah Tootakar Chaaho Mujhe Paagal Karado.""",
    """Meri Chahat Dekhni Hai To Mere Dil Par Apna Dil Rakhkar Dekh
Teri Dhadkan Naa Bhadjaye To Meri Mohabbat Thukra Dena""",
    """GalatFehmi Ki Gunjaish Nahi Sachchi Mohabbat Mein
Jahan Kirdaar Halka Ho Kahani Doob Jati Hai""",
    """Hone Do Mukhatib Mujhe Aaj In Honto Se Abbas
Baat Na To Ye Samjh Rahe Hai Par Guftagu Jari Hai""",
    """Kuch Is Adaa Se Haal Sunana Hamare Dil
Wo Khud Hi Keh De Kidi Bhul Jana Buri Baat Hai""",
    """Kisi Masoom Lamhe Main Kisi Masoom Chehre Se
Mohabbat Ki Nahi Jati Mohabbat Ho Jati Hai"""
  ];

  List<String> promise = [
    """Wada Hai Kabhi Na Hogi Duri Tumse Hamaari
Har Lamha Rahegi Chaahat Tumhaari
Pal Pal Chahenge Tumhen Is Kadar Ki
Ek Pal Bhee Tumhen Kamee Mehsoos Na Hogi Hamaari""",
    """Jab Tak Jivan Khatm Na Ho Jae
Ham Saath Saath Rahenge Ye Vaada Hai Mera Tumase""",
    """Main Tumhaari Yaadon Main Hamesha
Tumhare Saath Rahunga Ye Wada Hai Mera""",
    """Mujhe Chaand Tare Tod Ke Laane Ka Promis Mat Karana
Bas Unake Neche Hamesha Saath Rahane Ka Promisai Karana""",
    """Jis Se Wada Karo Vo Pura Karo
Hmesha Apane Kiye Hue Promise Ki Izzat Karo""",
    """Main Wda Karta Hu Ki Tujhe Kabhi
Akela Mahasoos Nahin Hone Dunga""",
    """Jab Tu Paas Nahi Hogi Tab Miss Karunga
Aaj Bas Tujhe Itana Hi Promisai Karoonga""",
    """Promisai Hai Hamara Na Chhodenge Kabhi Saath Tumhaara
Jo Gae Tum Hame Bhool Kar Le Ayenge Pakad Ke Haath Tumhaara""",
    """Khushaboo Ki Tarah Meri Har Saans Mein
Pyaar Apana Basaane Ka Vaada Karo
Rang Jitane Tumhaari Mohabbat Ke Hai
Mere Dil Mein Sajaane Ka Vaada Karo""",
    """As long as there’s a tomorrow after every today.
I promise to love you I’ll be there for you always and forever! Happy promise day!"""
  ];

  List<String> breakup = [
    """Dil Me Aaya Tha Wo Bahot Se Raston Se
Jane Ka Rasta Na Mil To Dil He Tod Diya.""",
    """Tumne Mujhe Mujhse Break Up Kar Liya 
Chalo Koi Baat Nahin. 
Jisake Lie Mujhse Break Up Kiya Hai 
Use Kabhi Mat Chhodna.""",
    """Dillagi na ho jaye kisi se bus ye khayal rakhna
dil to gujar jaate hau khuda ki kasam raaten nahi garti""",
    """Jo yahan se na jata tha kabhi
aaj wo yaha se chala gaya hai""",
    """Bichad ke mohabbat ke fasane yaad rehte hai
ujad jaati hai mehfil magar chehre yaad rehte hai""",
    """Akeen Tha Ki Tum Bhool Jaoge Mujhko
Khushi Hai Ki Hum Umeed Par Khare Utre""",
    """Adaa Hai Khwaab Hai Takseem Hai Tamaasha Hai
Meri Inn Aankhon Mein Ek Shakhs BeHatasha Hai""",
    """Dil Leke Muft Me Kahte Hai Kuch Kaam Ka Nhi
Ulti Shikayat Hai Ehsaan To Gaya""",
    """Raaz Khol Dete Hain Nazuk Se Ishaare Aksar
Kitni Khamosh Mohabbat Ki Jubaan Hoti Hai""",
    """Yahi Bahut Hai Ke Tumne Palat Ke Dekh Liya
Yeh Lutf Bhi Meri Ummeed Se Kuchh Zyada Hai"""
  ];

  List<String> friendship = [
    """Dawe Mujhe Dosti Ke Nahin Aate Yaar,
Ek Jaan Hai Jab Dil Chaahe Maang Lena.""",
    """Yahaan Qadam Qadam Par Naye Fankaar Milate Hain,
Lekin Qismat Vaalon Ko Sachche Yaar Milate Hain.
Best Friend Shayari And Friendship Shayari.""",
    """Sabane Kaha Dosti Ek Dard Hai,
Hamane Kaha Qubool Hai.
Sabane Kaha Is Dard Ka Saath Jee Nahin Paoge,
Hamane Kaha Teree Dosti Ke Saath Marana Bhee Qubool Hai.""",
    """Sharten Lagaee Nahin Jaatee Dostee Ke Saath,
Keejiye Mujhe Qubool Meree Har Kamee Ke Saath.""",
    """Dam Nahin Kisee Mein Kee Mita Sake Hamaaree Dostee Ko,
Jang Talavaaron Ko Lagata Hai Jigaree Yaar Ko Nahin.""",
    """Dil Se Khyaal-E-Dost Bhulaaya Na Jaayega,
Seene Mein Daag Hai Kee Mitaaya Na Jaayega.""",
    """Kisee Se Roj Milakar Baaten Karana Dostee Nahin,
Balki Kisee Se Bichhad Kar Yaad Rakhana Dostee Hai.""",
    """Jo Dil Ko Achchha Lagata Hai Usee Ko Dost Kahata Hoon,
Munaafiq Banakar Rishton Kee Siyaasat Main Nahin Karata.""",
    """Mulaaqaaten Zarooree Hai Agar Dostee Nibhaanee Hai Saaqee,
Lagaakar Bhool Jaane Se To Aksar Paudhe Sookh Jaate Hain.""",
    """Iraada To Dostee Ka Tha,
Lekin Mohabbat Ho Gayee."""
  ];

  List<String> attitude = [
    """Meri Bholi Shakal Par Mat Jao 
Agar Mai A For Attitude Dikhane 
Par Aa Gai To Tujhey Teri
A For Aukaat Nazar Aa Jayegi.""",
    """Sun Be Ladke Hamse Panga 
Aur Bhari Mafil Me Danga Dono Khatanak Hai.""",
    """Oppar Wale Ne Daulat Bhale He Kam Di Ho
Lekin Dost Sare Dildaar Diye Hain.""",
    """Ladka Hun Koi Pencil Nahin
Jo Sabhi Pe Line Marunga.
Mai Sirf Do Logon Se Pyar Karta Hun
Aik To Jinhon Ne Mujhey Janm Dia Hai
Aur Doosri Wo Pagli
Jisne Mere Liye Janm Liya Hai.""",
    """Pagal Aik Doosre Ke Jaisa
Hona Jaroori Nahin Hota
Aik Doosre Ke Liye Hona
Jaroori Hota Hai.""",
    """Tumne Poochha Tha Na Kaisa Hun Mai,
Kabhi Bhool Nahin Paoge Aisa Hun Mai.""",
    """Jyada Smart Banne Ki Koshish 
Mat Kar Kyonki Mere Baal Bhi 
Tere Aukaat Se Lambe Hain.""",
    """Hum Bure He Thee Hain
Jab Achchey The Tab Kausa 
Medal Mil Gaya Tha.""",
    """Hum Apna Waqt Barbaad Nahin Karte
Jo Hamne Bhool Gaya Hum Unhen Yaad Nahin Karte.""",
    """Stail 😎 Aisa Karo ☝ Kee Duniya Dekhatee 👫.
Jaaye Aur Yaaree 👫 Aisee Karo ☝ Kee Duniya Jalatee Jae 🔥😎."""
  ];

  List<String> hearttouching = [
    """Ham to bane he the tabaah hone ke liye
tera chhod jaana to mahaz bahaana ban gaya.""",
    """Bahut Shauk Tha Mujhe 
Sabako Khush Rakhane Ka.
Hosh Tab Aaya Jab Khud Ko 
Zaroorat Ke Wakt Akela Paaya.""",
    """Aaj Siddat Se Dil 
Chaah Raha Hai.
Koi Sirf Itana Poochh Le 
Tum Theek To Ho Na.

Aisa Kya Likhun Ki 
Tere Dil Ko Tasalli Ho Jaye.
Kya Yeh Batana Kafi Nahin 
Ki Meri Zindagi To Tum.""",
    """Hisaab Kitaab Na Poochh E Zindagi. 
Jab Toone Bhi Sitam Na Gine, 
To Hamane Bhi Zakhm Na Gine.""",
    """Hava Gujar Gai Patte 
Hile Bhee Nahin.
Wo Mere Shahar Mein Aaye
Aur Mile Bhee Nahin.""",
    """Ab To Daman-E- Dil Chor Do Bekaar Ummede
Bhut Dard Sah Liya Maine Bhut Dil Ji Liya Maine""",
    """Nahi Aati Khabar Koi Jang Ki Dusmano Ke Sahar Se
Kahe Rahe The Tum Nipat Lo Pahle Dosto Se Apne""",
    """Qabool Jurm Karte Hai Tere Kadmo Mein Gir Kar
Sajaye Maut Majzoor Hai Saheb Teri Judai Nahi""",
    """Meri Aankho Me Thi Hadse Jyada Beshumar Hai
Tera Hi Ishq Tera Hi Dard Tera Hi Intezaar Hai""",
    """Kiya Ghazle Kiya Isara Kiya Tarane Kiya Geet
Jab Yaar Hi Na Mila To Kiya Karna Daantan Dil Ko Ched Kr"""
  ];

  List<String> motivational = [
    """Wo Admi Success Nahin Ho Pata. 
Jisme Nakami Ka Khauph, 
Success Ki Chaahat Se Jyaadah Ho.""",
    """Jinaka Bharosa Oopar Vaala Ho, 
Unakee Manzil Kaamayaabee Hai.""",
    """Chahe Jitna Motivational Shayari Padh Loop
Lekin Kamyab Hone Ke Liye Jo Predna 
Relative Ke Tanon Se Milti Hai
Wah Kisi Aur Se Nahin Mil Sakti.""",
    """Kisi Ke Sath Time Waste Karne 
Se Achchha Hai Wo Time Apne Sapne
Ko Poora Karne Mein Invest Karo.""",
    """Bura Waqt Aik Aisi Tijori Hai
Jahan Se Safalta Ke Hathiya Milte Hain.""",
    """Jo Apne Aap Ko Padh Sakta Hai
Wo Duniyan Me Kuch Bhi Seekh Sakta Hai.""",
    """Manzil Ke Aage Badhkar Manzil Talash Kar, 
Mil Jaaye Tujhako Dariya To Samandar Talash Kar.""",
    """Kabhi Patthar Ki Thokar Se Bhi Nahi Aati Jara Si Kharoch. 
Kabhi Jara Si Baat Pe Insan Bikhar Jata Hai. """,
    """Shakhon Se Toot Jaen Vo Patte Nahin Hain Ham, 
Aandhiyon Se Kah Do Jara Aukaat Mein Rahen.""",
    """Hadson Ki Maar Se Toote Magar Zindah Hain
Zindagi Jo Zakhm Bhi Toone Diya Gahra Na Tha"""
  ];

  List<String> funny = [
    """Dil Me Bhut Dard Hai Doctor Ke Pas Gaya
Doctor Ne Girlfriend Ki Kami Batai""",
    """Agar Jaldbazi Mein Shaadi Karke Jeevan Bigaad Loge
Soch Samajh Kar Karoge Toh Kaun Sa Teer Maar Loge""",
    """Jisko Sugar Hai Kripya Wo Log Sabr Ka Karen
Kyukee Sabr Ka Phal Meetha Hota Hai""",
    """Maaf Karo Parmeshwar Yeh Bhaari Bhool Humari Hai
Shaadi Kar Li Jis Se Humne Woh Toh Nirdhan Nari Hai""",
    """Too Tik Tok Ki Rani Main Fecbook Ka Raja
Milana Hai To Whatsapp Pe Aaja""",
    """Biwi Bhi Haq Jtati Hai Maa Bhi Haq Jtati Hai
Shaadi Ke Baad Aadmi Kashmir Ho Jata Hai""",
    """Maine Zindagi Se Pucha Tu Khoobsurat Hai Badsurat
Palat Kar Usne Jawab Diya Jaise Badmash Teri Soorat""",
    """Hamari Kismat Hi Kuchh Aisi Nikli Ghalib
Zameen Mili Toh Banjar Aur Admin Mila Toh Kanjar""",
    """Mera Dil Bhi Le Gayi Mera Chain Bhi Le Gayi
Had Ho Gayi Jab Jab Maine Dekha Wo Mera Paanch Rupaiya Ka Pen Bhi Le Gayi""",
    """Kuch Aise Hadse Bhi Hote Hai Zindgi Mein Dost
Hajaar Ka Note Rakhne Wale Sau Rupaye Mangte Hain"""
  ];
}
