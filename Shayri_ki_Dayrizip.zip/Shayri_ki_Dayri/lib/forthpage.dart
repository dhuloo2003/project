
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:path_provider/path_provider.dart';

import 'package:share_plus/share_plus.dart';

class forthpage extends StatefulWidget {
  List temp;
  int index;

  forthpage(this.temp, this.index);

  @override
  State<forthpage> createState() => _forthpageState();
}

class _forthpageState extends State<forthpage> {
  int i = 8, j = 30, t = 6, em = 2,v=1;
  double text_size =
      18; //i for backgrounf color, j for text background color , t for text color, v is for fontstyle ,em for emoji
  List<String> lis = [
    'Background Color',
    'Text Color',
    'Text Size',
    'Font',
    'Emoji',
    'Share'
  ];
  List emoj = [
    '❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤',
    '💖💗🥰💞💖💗🥰💞💖💗🥰💞💖💗💖💗🥰💞💖💗🥰💞💖💗🥰💞💖💗',
    '🐱🐈🐈‍⬛(^ .‿. ^)🐱🐈🐈‍⬛',
    '🦋🌸𓍯૮₍ ´• ˕ • ₎ა🌸🧸🦋🌸𓍯૮₍ ´• ˕ • ₎ა🌸🧸',
    '( 💕 ŐωŐ 💕 )( 💕 ŐωŐ 💕 )',
    '(•_•) ( •_•)>⌐■-■ (⌐■_■)',
    '🦋🌸𓍯૮₍ ´• ˕ • ₎ა🌸🧸🦋🌸𓍯૮₍ ´• ˕ • ₎ა🌸🧸',
    '🥺💌💍🥺💌💍🥺💌💍🥺💌💍🥺💌💍🥺💌💍🥺💌💍🥺',
    '😎🤏😳🕶🤏😎🤏😳🕶🤏😎🤏😳🕶🤏',
    '🌼😍💓👉🏻👈🏻💞🌷🥺💍💫🌼😍💓👉🏻👈🏻💞🌷🥺💍💫'
  ];
  List<Color> colorlist = [
    Colors.red, //   ❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤❤
    Colors.green,
    Colors.grey,
    Colors.blue,
    Colors.yellow,
    Colors.pink,
    Colors.black,
    Colors.orange,
    Colors.white70,
    Colors.purple,
    Colors.cyan,
    Colors.cyanAccent,
    Colors.lightGreenAccent,
    Colors.orangeAccent,
    Colors.tealAccent,
    Colors.indigo,
    Colors.deepPurpleAccent,
    Colors.indigoAccent,
    Colors.brown,
    Colors.blueGrey,
    Colors.lightGreen,
    Colors.lightBlueAccent,
    Colors.teal,
    Colors.purpleAccent,
    Colors.deepOrangeAccent,
    Colors.redAccent,
    Colors.green.shade300,
    Colors.grey.shade500,
    Colors.blue.shade200,
    Colors.yellow.shade300,
    Colors.white,
    Colors.pink.shade300,
    Colors.purpleAccent.shade100,
    Colors.orange.shade300,
    Colors.redAccent.shade700,
    Colors.greenAccent.shade700,
    Colors.blueGrey.shade900,
    Colors.blueAccent.shade700,
    Colors.yellowAccent.shade700,
    Colors.pinkAccent.shade700,
    Colors.black87,
    Colors.orangeAccent.shade700,
  ];
  List<String> fontstyl=['family1','family2','family3','family4','family5','family6','family7','family8','family9','family10',
    'family11','family12','family13','family14','family15','family16','family17','family18','family19','family20',
    'family21','family22','family23','family24','family25','family26','family27','family28','family29','family30',
    'family31','family32','family33','family34','family35','family36','family37','family38','family39','family40',
    'family41','family42','family43','family44','family45','family46','family47','family48','family49','family50',
    'family51','family52','family53','family54','family55','family56','family57','family58','family59','family60','family61','family62',];
GlobalKey _globalKey=GlobalKey();
  String folderpath="";
  @override
  void initState() {
    super.initState();
    creatfolder();
  }
  creatfolder() async {
    Directory? directory= await  getExternalStorageDirectory();

    if(await directory!.exists()){
      print("folder already created");
    }else{
      print("folder created");
      await directory.create();
    }
    folderpath=directory.path;
  }
  Future<Uint8List> _capturePng() async {
    try {
      print('inside');
      RenderRepaintBoundary? boundary =
      _globalKey.currentContext!.findRenderObject() as RenderRepaintBoundary?;
      ui.Image image = await boundary!.toImage(pixelRatio: 3.0);
      ByteData? byteData =
      await image.toByteData(format: ui.ImageByteFormat.png);
      var pngBytes = byteData!.buffer.asUint8List();
      var bs64 = base64Encode(pngBytes);
      print(pngBytes);
      setState(() {});
      return pngBytes;
    } catch (e) {
      return Future.value();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colorlist[i],
      appBar: AppBar(
        title: Text("Shayri Edit Kare",style: TextStyle(fontFamily: fontstyl[v],color: colorlist[t]),),
        centerTitle: true,
        backgroundColor: colorlist[i],
      ),
      body: Column(
        children: [
          Expanded(flex: 5,
            child: Container(height: 300,
              alignment: Alignment.center,margin: EdgeInsets.all(10),

              child: ListView(scrollDirection: Axis.vertical,
                shrinkWrap: true,padding: EdgeInsets.all(10),
                children: [
                  RepaintBoundary(key: _globalKey,
                    child: Container(decoration: BoxDecoration(
                        color: currentColor,
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: Colors.grey, width: 5)),
                      alignment: Alignment.center,
                      child: Text(
                        "${emoj[em]} \n ${widget.temp[widget.index]} \n ${emoj[em]}",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: text_size,
                            color: colorlist[t],
                            fontFamily: fontstyl[v]
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Spacer(),
          Expanded(flex: 2 ,
            child: Container(
              padding: EdgeInsets.all(5),
              alignment: Alignment.center,
              color: Colors.grey[300],
              width: double.infinity,
              child: Column(
                children: [
                  Expanded(
                    flex: 1,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                            onPressed: () {
                              i++;
                              if (i == colorlist.length) {
                                i = 0;
                              }
                              setState(() {});
                            },
                            icon: Icon(
                              Icons.published_with_changes_outlined,
                            )),
                        IconButton(
                            onPressed: () {
                              // Navigator.push(context, MaterialPageRoute(builder: (context) {
                              //     third([t,j,t]);
                              //   },));
                            },
                            icon: Icon(Icons.save_alt))
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: Container(
                      child: GridView(
                          children: [
                            contain(0),
                            contain(1),
                            contain(2),
                            contain(3),
                            contain(4),
                            contain(5),
                          ],
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisSpacing: 5,
                              childAspectRatio: 2.25,
                              mainAxisSpacing: 5,
                              crossAxisCount: 3)),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
  void changeColor(Color color) {
    setState(() => pickerColor = color);
  }
Color pickerColor=Color(0xff443a49);
  Color currentColor = Color(0xff443a49);
  contain(int k) {
    return InkWell(
      onTap: () {
        if (k == 0) {
          showDialog(
            builder: (context) => AlertDialog(
              title: const Text('Pick a color!'),
              content: SingleChildScrollView(
                child: ColorPicker(
                  pickerColor: pickerColor,
                  onColorChanged: changeColor,
                ),
              ),
              actions: <Widget>[
                ElevatedButton(
                  child: const Text('Got it'),
                  onPressed: () {
                    setState(() => currentColor = pickerColor);
                    Navigator.of(context).pop();
                  },
                ),
              ],
            ), context: context,
          );

          // showModalBottomSheet(
          //   builder: (context) {
          //     return backcolor();
          //   },
          //   context: context,
          // );
        } else if (k == 1) {
          showModalBottomSheet(
            builder: (context) {
              return textcolor();
            },
            context: context,
          );
        }
        else if (k == 2) {
          showModalBottomSheet(
            builder: (context) {
              return textsize();
            },
            context: context,
          );
        }
        else if (k == 3) {
          showModalBottomSheet(
            builder: (context) {
              return fontfam();
            },
            context: context,
          );
        }
        else if (k == 4) {
          showModalBottomSheet(
            builder: (context) {
              return emoji();
            },
            context: context,
          );
        }
        else if(k==5){
          _capturePng().then((value) async {
            print(value);
            DateTime d=DateTime.now();
            print(d);
            String time="${d.year}${d.month}${d.day}${d.hour}${d.minute}${d.second}${d.millisecond}";
            String imagepath="${folderpath}/Image$time.jpg";
            File file=File(imagepath);
            await file.create();
            file.writeAsBytesSync(value);
            Share.shareFiles([file.path], text: 'Great picture');
          });
        }
      },
      child: Container(
        color: Colors.red,
        child: Text("${lis[k]}"),
        alignment: Alignment.center,
      ),
    );
  }
  backcolor() {
    return Container(
      height: 150,
      padding: EdgeInsets.all(5),
      child: GridView.builder(
        itemCount: colorlist.length,
        itemBuilder: (context, index) {
          return InkWell(
            onTap: () {
              j = index;
              setState(() {});
            },
            child: Container(
              color: colorlist[index],
            ),
          );
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 8, crossAxisSpacing: 5, mainAxisSpacing: 6),
      ),
    );
  }

  textcolor() {
    return Container(
      height: 150,
      padding: EdgeInsets.all(5),
      child: GridView.builder(
        itemCount: colorlist.length,
        itemBuilder: (context, index) {
          return InkWell(
            onTap: () {
              t = index;
              setState(() {});
            },
            child: Container(
              color: colorlist[index],
            ),
          );
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 8, crossAxisSpacing: 5, mainAxisSpacing: 6),
      ),
    );
  }

  emoji() {
    return Container(
      height: 165,
      child: ListView.builder(
        padding: EdgeInsets.all(10),
        itemCount: emoj.length,
        itemBuilder: (context, index) {
          return InkWell(
            hoverColor: Colors.white,
            onTap: () {
              em = index;
              setState(() {});
            },
            child: Container(
                alignment: Alignment.center,
                height: 50,
                child: Text(
                  "${emoj[index]}",
                  textAlign: TextAlign.center,
                )),
          );
        },
      ),
    );
  }

  textsize() {
    return Container(
        height: 175,
        child: StatefulBuilder(
          builder: (context, setState1) {
            return Slider(
              min: 10,
              max: 50,
              onChanged: (value) {
                text_size = value;
                setState(() {});
                setState1(() {});
              },
              value: text_size,
            );
          },
        ));
  }
  fontfam(){
    return Container(height: 175,alignment: Alignment.center,padding: EdgeInsets.all(5),
      child: GridView.builder(
        itemCount: fontstyl.length,
        itemBuilder: (context, index) {
        return InkWell(onTap: () {
          v=index;
          setState((){});
        },
        child: Container(alignment: Alignment.center,color: Colors.orange,child: Text("${fontstyl[index]}",textAlign: TextAlign.center,),),
        );
      },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4,crossAxisSpacing: 5,mainAxisSpacing: 5,childAspectRatio: 1.75),),
    );
  }

}

