
import 'package:flutter/material.dart';
import 'package:shayri_ki_dayri/list.dart';
import 'third_page.dart';


class second extends StatefulWidget {
  int index;
  second(this.index);
  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  List<String> pic = [
    'imag/sad.jpeg',
    'imag/loveshayri.jpeg',
    'imag/alone.jpeg',
    'imag/attitude.jpeg',
    'imag/breakup.jpeg',
    'imag/friendship.jpeg',
    'imag/funny.jpeg',
    'imag/motivation.jpeg',
    'imag/promise.jpeg',
    'imag/romentic.jpeg',
  ];
  List<String> title = [
    'Sad Shayri',
    'Love Shayri',
    'Alone Shayri',
    'Attitude Shayri',
    'Breakup Shayri',
    'Friendship',
    'Funny Shayri',
    'Motivation Shayri',
    'Promise Shayri',
    'Romentic Shayri'
  ];
  List temp=[];
  list l=list();


  @override
  void initState() {
    super.initState();
    switch(widget.index){
      case 0:
        temp=l.love;break;
      case 1:
        temp=l.sad;break;
      case 2:
        temp=l.hearttouching;break;
      case 3:
        temp=l.attitude;break;
      case 4:
        temp=l.breakup;break;
      case 5:
        temp=l.friendship;break;
      case 6:
        temp=l.funny;break;
      case 7:
        temp=l.motivational;break;
      case 8:
        temp=l.promise;break;
      case 9:
        temp=l.romantic;break;
    }
  }
  int id=0;
  List<Color> color=[Colors.grey,Colors.white,Colors.white70,Colors.black];
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.grey[200],
      appBar: AppBar(title: Text("${title[widget.index]}",style: TextStyle(color: color[3]),),centerTitle: true,backgroundColor: Colors.grey[200],),
      body: ListView.builder(
        itemCount: temp.length,
        itemBuilder: (context, index) {
          return InkWell(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                id=widget.index;
                return third(index,id,temp,pic,title);
              },));
            },
            child: Container(margin: EdgeInsets.only(left: 10,top: 5,bottom: 5,right: 10),
              decoration: BoxDecoration(
                  color: color[1],
                  border: Border.all(color: Colors.black12,width: 2),
                  borderRadius: BorderRadius.circular(5)
              ),
              child: Row(
                children: [
                  Container(margin: EdgeInsets.only(top: 5,bottom: 5,left: 5),height: 35,width: 35,
                    child: Image.asset("${pic[widget.index]}",fit: BoxFit.fill,),
                  ),
                  Expanded(flex: 4,
                      child: Container(margin: EdgeInsets.only(left: 10),
                        child: Text("${temp[index]}", maxLines: 1,style: TextStyle(color: color[3]),),
                      ))
                ],
              ),
            ),
          );
        },),

    );
  }
}