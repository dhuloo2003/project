
import 'package:clipboard/clipboard.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:share_plus/share_plus.dart';
import 'forthpage.dart';

class third extends StatefulWidget {
  int no, id;
  List temp;
  List<String> pic, title;

  third(this.no, this.id, this.temp, this.pic, this.title);

  @override
  State<third> createState() => _thirdState();
}

class _thirdState extends State<third> {
  int i = 8,
      j = 30,
      t = 6,no=0,v=1; //i for backgrounf color, j for text background color, t for text color  , v is for fontstyle
  List<FontStyle> font=[FontStyle.italic,FontStyle.normal];
  List<Color> colorlist = [
    Colors.red,
    Colors.green,
    Colors.grey,
    Colors.blue,
    Colors.yellow,
    Colors.pink,
    Colors.black,
    Colors.orange,
    Colors.purple,
    Colors.cyan,
    Colors.cyanAccent,
    Colors.lightGreenAccent,
    Colors.orangeAccent,
    Colors.tealAccent,
    Colors.indigo,
    Colors.deepPurpleAccent,
    Colors.indigoAccent,
    Colors.brown,
    Colors.blueGrey,
    Colors.lightGreen,
    Colors.lightBlueAccent,
    Colors.teal,
    Colors.purpleAccent,
    Colors.deepOrangeAccent,
    Colors.redAccent,
    Colors.green.shade300,
    Colors.grey.shade500,
    Colors.blue.shade200,
    Colors.yellow.shade300,
    Colors.pink.shade300,
    Colors.purpleAccent.shade100,
    Colors.orange.shade300,
    Colors.redAccent.shade700,
    Colors.greenAccent.shade700,
    Colors.blueGrey.shade900,
    Colors.blueAccent.shade700,
    Colors.yellowAccent.shade700,
    Colors.pinkAccent.shade700,
    Colors.black87,
    Colors.orangeAccent.shade700,
  ];
  List<String> fontstyl=['family1','family2','family3','family4','family5','family6','family7','family8','family9','family10',
    'family11','family12','family13','family14','family15','family16','family17','family18','family19','family20',
    'family21','family22','family23','family24','family25','family26','family27','family28','family29','family30',
    'family31','family32','family33','family34','family35','family36','family37','family38','family39','family40',
    'family41','family42','family43','family44','family45','family46','family47','family48','family49','family50',
    'family51','family52','family53','family54','family55','family56','family57','family58','family59','family60','family61','family62',];
  int  id = 0;
  List temp = [];
  List<String> pic = [],
      title = [];
  List<Color> color=[Colors.white70,Colors.white,Colors.white70,Colors.black];
PageController pageController=PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: color[0],
      appBar: AppBar(
        title: Text("${title[id]}",style: TextStyle(color: color[3]),),
        backgroundColor: color[0],
      ),
      body: Container(
        child: Column(
          children: [
            Expanded(flex: 4, child: Column(
              children: [
                Expanded(flex: 1,
                    child: Row(mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("${no + 1}/${temp.length}",
                          style: TextStyle(color: color[3],
                              fontSize: 20),)
                      ],
                    )),
                Expanded(flex: 5,
                  child: Container(padding: EdgeInsets.only(
                      top: 0, bottom: 40, left: 70, right: 70),
                    width: double.infinity,
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.black12, width: 0),
                          borderRadius: BorderRadius.circular(20)
                      ),
                      child: ClipRRect(borderRadius: BorderRadius.circular(10),
                        child: Image.asset(
                          "${pic[id]}", fit: BoxFit.fill,
                          height: 200,
                          width: 100,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            )),
            Expanded(flex: 5,
                child: Container(
                  padding: EdgeInsets.only(
                      left: 20, right: 20, top: 0, bottom: 0),
                  alignment: Alignment.center,
                  child: Column(
                    children: [
                      Expanded(flex: 5,
                          child: Container(
                            child: PageView.builder(onPageChanged: (value) {
                              no=value;
                              setState((){});
                            },padEnds: true,
                              controller: pageController,
                              itemCount: temp.length,
                              itemBuilder: (context, index) {
                                return Container(
                                  alignment: Alignment.center,
                                  margin: EdgeInsets.only(bottom: 30),
                                  padding: EdgeInsets.only(
                                      left: 20, right: 20, top: 0, bottom: 20),
                                  decoration: BoxDecoration(
                                      color: color[1],
                                      border: Border.all(
                                        color: Colors.black12,
                                        width: 5,
                                      ),
                                      borderRadius: BorderRadius.circular(30)),
                                  child: Text("${temp[no]}",
                                    style: TextStyle(fontSize: 20, color: (color[0]!='Colors.white')?color[3]:Colors.white ),textAlign: TextAlign.center,),
                                );
                              },),
                          )),
                      Expanded(
                          flex: 1, child: Row(mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(onPressed: () {

                                if (no > 0) {
                                  no--;
                                  pageController.jumpToPage(no);
                                }
                                setState(() {});
                              },
                                  icon: Icon(Icons.arrow_back_ios,
                                    color: Colors.black)),
                              IconButton(onPressed: () {
                                FlutterClipboard.copy(temp[no]).then(( value ) =>
                                    Fluttertoast.showToast(
                                        msg: "Copied",
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.BOTTOM,
                                        timeInSecForIosWeb: 1,
                                        backgroundColor: Colors.red,
                                        textColor: Colors.white,
                                        fontSize: 16.0
                                    ),
                                );
                              },
                                  icon: Icon(
                                    Icons.copy, color: Colors.black,)),
                              IconButton(onPressed: () {
                                Navigator.push(context,
                                    MaterialPageRoute(builder: (context) {
                                      return forthpage(temp, no);
                                    },));
                              },
                                  icon: Icon(
                                    Icons.edit_off, color: Colors.black,)),
                              IconButton(onPressed: () {
                                Share.share('check out my website https://example.com', subject: temp[no]);
                              },
                                  icon: Icon(
                                    Icons.share, color: Colors.black,)),
                              IconButton(onPressed: () {

                                if (no < 9) {
                                  no++;
                                  pageController.jumpToPage(no);
                                }
                                setState(() {});
                              },
                                  icon: Icon(Icons.arrow_forward_ios,
                                    color: Colors.black,))
                            ],
                          ))
                    ],
                  ),
                ))
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    no = widget.no;
    pageController=PageController(initialPage: no);
    id = widget.id;
    temp = widget.temp;
    pic = widget.pic;
    title = widget.title;
  }
}
