import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shayri_ki_dayri/sec_page.dart';

class shayar extends StatefulWidget {
  const shayar({Key? key}) : super(key: key);

  @override
  State<shayar> createState() => _shayarState();
}

class _shayarState extends State<shayar> {
  gonext() async {
    var status = await Permission.storage.status;
    if(status.isDenied){
      await [Permission.storage].request();
    }
    await Future.delayed(Duration(seconds: 2));
  }

  @override
  void initState() {
    super.initState();
    gonext();
  }

  List<Color> color=[Colors.grey,Colors.white,Colors.white70,Colors.black];
  List<String> pic = [
    'imag/sad.jpeg',
    'imag/loveshayri.jpeg',
    'imag/alone.jpeg',
    'imag/attitude.jpeg',
    'imag/breakup.jpeg',
    'imag/friendship.jpeg',
    'imag/funny.jpeg',
    'imag/motivation.jpeg',
    'imag/promise.jpeg',
    'imag/romentic.jpeg',
  ];
  List<String> title = [
    'Sad Shayri',
    'Love Shayri',
    'Alone Shayri',
    'Attitude Shayri',
    'Breakup Shayri',
    'Friendship',
    'Funny Shayri',
    'Motivation Shayri',
    'Promise Shayri',
    'Romentic Shayri'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.grey[200],
        appBar: AppBar(
          centerTitle: true,
          title: Text("Shayri Ki Dayri",style: TextStyle(color: color[3]),),
          backgroundColor: Colors.grey[200],
          elevation: 20,
        ),
        body: ListView.builder(
          itemCount: title.length,
          itemBuilder: (context, index) {
            return Column(
              children: [
                InkWell(onTapDown: (details) {
                  Colors.yellow;
                }, hoverColor: Colors.green[400],
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) {
                          return second(index);
                        },
                      ));
                    },
                    child: Container(margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(color: color[1],
                        border: Border.all(color: Colors.black12, width: 5),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Row(
                        children: [
                          Container(
                            margin: EdgeInsets.only(left: 10),
                            height: 50,
                            width: 50,

                            child: Image.asset(
                              pic[index],
                              fit: BoxFit.fill,
                              // fit: BoxFit.fitWidth,
                            ),
                          ),
                          Expanded(
                              child: Container(
                                margin: EdgeInsets.only(left: 25),
                                alignment: Alignment.centerLeft,
                                height: 100,
                                width: 100,
                                child: Text(
                                  title[index],
                                  style: TextStyle(fontSize: 22,color: color[3]),
                                ),
                              )),
                          Container(margin: EdgeInsets.only(right: 10),
                            child: Icon(Icons.arrow_forward_ios_outlined,color: color[3],),
                          )
                        ],
                      ),
                    )
                ),
              ],
            );
          },)
    );
  }
}