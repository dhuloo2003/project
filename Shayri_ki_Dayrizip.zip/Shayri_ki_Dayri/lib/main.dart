import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter/material.dart';
import 'firstpage.dart';

void main() {
  runApp(MaterialApp(
    home: AnimatedSplashScreen(
        splash: Image.asset("imag/breakup.jpeg"),
        duration: 1500,
        splashTransition: SplashTransition.fadeTransition,
        nextScreen: shayar(),

    ),
  ));
}

