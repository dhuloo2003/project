import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(home: demo(),));
}
class demo extends StatefulWidget {
  const demo({Key? key}) : super(key: key);

  @override
  State<demo> createState() => _demoState();
}

class _demoState extends State<demo> {
   Stream<String> fun1() async* {
    while(true) {
      await Future.delayed(Duration(seconds: 1));
      DateTime d=DateTime.now();
      String time="${d.hour} : ${d.minute} : ${d.second}";
      yield time;
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Center(
        child: StreamBuilder(
          stream: fun1(),
          builder: (context, snapshot) {
          if(snapshot.connectionState==ConnectionState.waiting){
            return Center(child: CircularProgressIndicator(),);
          }
          else if(snapshot.hasData){
            String l=snapshot.data as String;
            return Center(child: Text("$l",style: TextStyle(fontSize: 30)),);
          }
          else{
            return Center(child: Text("00 : 00 : 00"),);
          }
        },),
      )),
    );
  }
}
