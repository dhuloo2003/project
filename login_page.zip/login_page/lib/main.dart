import 'package:flutter/material.dart';
import 'package:login_page/secpage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'model.dart';
import 'firstpage.dart';

void main(){
  runApp(MaterialApp(home: demo(),));
}
class demo extends StatefulWidget {
  const demo({Key? key}) : super(key: key);

  @override
  State<demo> createState() => _demoState();
}

class _demoState extends State<demo> {
  String? sgf;

  @override
  void initState() {
    super.initState();
    initpref();
  }

  Future<StatefulWidget> initpref() async {
    model.pref = await SharedPreferences.getInstance();
    sgf=model.pref!.getString("login")??"pleaselogin";
    if(sgf=="alreadylogin"){
      print("alreadylogin");
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
        return secpage();
      },));
    }
    else{
      print("please login");
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
        return firstpage();
      },));
    }
    return Future.value();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
