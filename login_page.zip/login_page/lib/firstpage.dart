import 'package:flutter/material.dart';
import 'package:login_page/secpage.dart';
import 'model.dart';

class firstpage extends StatefulWidget {
  const firstpage({Key? key}) : super(key: key);

  @override
  State<firstpage> createState() => _firstpageState();
}

class _firstpageState extends State<firstpage> {
  TextEditingController user= TextEditingController();
  TextEditingController pass= TextEditingController();
  bool status=false;
  @override
  void initState() {
    super.initState();

  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.white,
      body: SafeArea(
          child: Column(
        children: [
          Expanded(flex: 5,
              child: Container(margin: EdgeInsets.only(bottom: 15),width: double.infinity,
                child: Column(
                  children: [
                    Expanded(flex: 3,child: Container(margin: EdgeInsets.only(top: 50),
                      child: Image.asset("photos/1.png"),alignment: Alignment.bottomCenter,
                    )),
                    Expanded(child: Container(margin: EdgeInsets.only(right: 40),
                      alignment: Alignment.topRight,
                      child: Text("Login",style: TextStyle(fontSize: 24,color: Colors.white),),
                    ))
                  ],
                ),

                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.orange.shade800,Colors.orange.shade600,Colors.orange],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                  ),
                    borderRadius: BorderRadius.only(bottomLeft:  Radius.circular(150))
                ),
          )),
          Expanded(flex: 1,
            child: Container(margin: EdgeInsets.only(bottom: 0,left: 50,right: 50,top: 0),
              padding: EdgeInsets.only(left: 10),
              child: TextField(
                controller: user,
                  decoration: InputDecoration(
                    hintText: "User name",
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.person)
                  ),
              ),
            ),
          ),
          Expanded(flex: 1,
            child: Container(margin: EdgeInsets.only(bottom: 0,left: 50,right: 50,top: 0),
              padding: EdgeInsets.only(left: 10),
              child: TextField(
              controller: pass,
              obscureText: true,
              decoration: InputDecoration(
                  hintText: "Password",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.key)
              ),
            ),
            ),
          ),
          Expanded(flex: 2,
            child: Container(margin: EdgeInsets.only(bottom: 5,left: 50,right: 50,top: 0),alignment: Alignment.topRight,

              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30)),
                child: Text("Forget Password ?"),
            ),
          ),
          Expanded(
            child: InkWell(
              onTap: () async {

                if(user.text.toString()=="admin" && pass.text.toString()=="admin"){
                  await model.pref!.setString("login", "alreadylogin");
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                    return secpage();
                  },));
                }

              },
              child: Container(margin: EdgeInsets.only(bottom: 5,left: 50,right: 50,top: 10),
               alignment: Alignment.center,
                decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [Colors.orange,Colors.orange.shade700]),
                    borderRadius: BorderRadius.circular(30)),
                child: Text("LOGIN"),
              ),
            ),
          ),Spacer(),
          Expanded(child: Container(padding: EdgeInsets.only(bottom:15),
              alignment: Alignment.bottomCenter,
              child: Text("Don't have an account ? Register")))
        ],
      )),
    );
  }
}
