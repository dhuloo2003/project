import 'package:flutter/material.dart';
import 'package:login_page/firstpage.dart';
import 'package:login_page/model.dart';

class secpage extends StatefulWidget {
  const secpage({Key? key}) : super(key: key);

  @override
  State<secpage> createState() => _secpageState();
}

class _secpageState extends State<secpage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Column(
        children: [
          Expanded(child: Container(child: Text("You are Login"),)),
          Expanded(child: Container(
            child: ElevatedButton(onPressed: () async {
              await model.pref!.setString("login", "Logout");
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                return firstpage();
              },));
            }, child: Text("Log Out")),
          )),
        ],
      )),
    );
  }

}
