import 'package:shared_preferences/shared_preferences.dart';

class model{
  static SharedPreferences? pref;
}