import 'package:demo_bloc/demoblocfolder/mybloc_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:provider/provider.dart';

import 'demoblocfolder/startpro.dart';

void main(){
  runApp(
    MultiProvider(providers: [
      BlocProvider(create: (context) => MyblocBloc(),)
    ],
      child: MaterialApp(home: startpro(),),
    ),
  );
}