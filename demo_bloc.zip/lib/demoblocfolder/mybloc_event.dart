part of 'mybloc_bloc.dart';

@immutable
abstract class MyblocEvent {}

class initstart extends MyblocEvent{
  int i;
  initstart(this.i);
}

class increment extends MyblocEvent{

}
class decrement extends MyblocEvent{

}