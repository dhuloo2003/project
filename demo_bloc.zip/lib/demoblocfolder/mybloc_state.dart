part of 'mybloc_bloc.dart';

@immutable
abstract class MyblocState {}

class MyblocInitial extends MyblocState {}


class firstinitial extends MyblocState{
  int cnt;
  firstinitial(this.cnt);
}