import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'mybloc_event.dart';
part 'mybloc_state.dart';

class MyblocBloc extends Bloc<MyblocEvent, MyblocState> {

  int cnt=0;

  MyblocBloc() : super(MyblocInitial()) {
    on<MyblocEvent>((event, emit) {
      // TODO: implement event handler
    });
    on<initstart>((event, emit) {
      cnt=event.i;
      emit(firstinitial(cnt));
    });
    on<increment>((event, emit) {
      cnt++;
      emit(firstinitial(cnt));
    });
    on<decrement>((event, emit) {
      cnt--;
      emit(firstinitial(cnt));
    });
  }
}
