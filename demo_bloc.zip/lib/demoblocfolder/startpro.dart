import 'package:demo_bloc/demoblocfolder/mybloc_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class startpro extends StatefulWidget {
  const startpro({Key? key}) : super(key: key);

  @override
  State<startpro> createState() => _startproState();
}

class _startproState extends State<startpro> {
  MyblocBloc? db;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    db=BlocProvider.of<MyblocBloc>(context);

    db!.add(initstart(10));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Bloc Architecture")),
      body: Column(
        children: [
          BlocBuilder<MyblocBloc,MyblocState>(builder: (context, state) {
            if(state is firstinitial){
              return Text("${state.cnt}",style: TextStyle(fontSize: 50),);
            }
            return Text("0");
          },),
          ElevatedButton(onPressed: () {
            db!.add(increment());
          }, child: Text("Increment")),
          ElevatedButton(onPressed: () {
            db!.add(decrement());
          }, child: Text("Decrement")),
        ],
      ),
    );
  }
}
