
import 'package:flutter/material.dart';

import 'secondpage.dart';

void main() {
  runApp(MaterialApp(
    home: firstpage(),
  ));
}

class firstpage extends StatefulWidget {
  const firstpage({Key? key}) : super(key: key);

  @override
  State<firstpage> createState() => _firstpageState();
}

class _firstpageState extends State<firstpage> {
  List<String> burger=["Veg Burger",
    "Chees Burger",
    "Aloo Tiki Burger",
    "Chinees Burger",
    "Maxicon Aloo Tiki Burger",
    "Kaju Kari",
    "Pannir Tika",
    "Pannir Handi",
    "Chole Bhuture",
    "Dal Makhni"
  ];
  bool vegburger = false;
  List<bool> catagori=[false,false,false,false,false,false,false,false,false,false];
  List<String> sel_ro=['0','0','0','0','0','0','0','0','0','0','0','0'];
List<String> items=['0','1','2','3','4','5'];
List<String> price=['50','70','40','60','80','150','200','220','100','170'];

int total=0;

List<String> img=['vegburger.jpeg',
  'cheesburger.jpeg',
  'chiness.jpeg',
  'alootiki.jpeg',
  'macalotiki.jpeg','kajukari.jpeg','pannirtika.jpeg','pannirhandi.jpeg','cholebhature.jpeg','dalmakhni.jpeg',


];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Restraunt Menu"),backgroundColor: Color(0xFFF16767),
      ),
      body: Container(height: double.infinity,width: double.infinity,
        child: Stack(
          children: [
            Container(height: double.infinity,width: double.infinity,
              color: Color(0xFFEAE7E7),
            ),
            Container(height: double.infinity,width: 130,
              color: Colors.redAccent,
            ),
            SingleChildScrollView(scrollDirection: Axis.vertical,
              child: Column(
                children: [
                  // Container(height: 100,width: double.infinity,child: Text("Burger",style: TextStyle(fontSize: 26),),
                  //   alignment: Alignment.center,),
                  listrow(0),
                  listrow(1),
                  listrow(2),
                  listrow(3),
                  listrow(4),
                  listrow(5),
                  listrow(6),
                  listrow(7),
                  listrow(8),

                  listrow(9),
                  Row(
                    children: [
                      Expanded(
                        child: Container(height: 90,alignment: Alignment.center,margin: EdgeInsets.only(top: 7,bottom: 7),
                          decoration: BoxDecoration(
                              color: Colors.white,borderRadius: BorderRadius.circular(10)
                          ),
                          child: Text("Total = $total",style: TextStyle(fontSize: 24),),
                        ),
                      ),
                      Expanded(
                        child: InkWell(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return secondpage(total);
                            },));
                          },
                          child: Container(height: 90,alignment: Alignment.center,
                            margin: EdgeInsets.only(top: 7,bottom: 7,right: 7,left: 7),
                            decoration: BoxDecoration(
                                color: Colors.white,borderRadius: BorderRadius.circular(10)
                            ),
                            child: Text("Order Now",style: TextStyle(fontSize: 24),),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        )
      ),
    );
  }
  int g=0,n=0;
  List<int> pri=[0,0,0,0,0,0,0,0,0,0];
  listrow(int i){
    return InkWell(onTap: () {
      setState(() {
        if(catagori[i]) {
          catagori[i] =false;
          sel_ro[i] = '0';
          pri[i]=0;
          print('pri  =  ${pri[i]}');
          total=pri[0]+pri[1]+pri[2]+pri[3]+pri[4]+pri[5]+pri[6]+pri[7]+pri[8]+pri[9];

          print("Total =$total");
        }
        else{
          catagori[i]=true;
          sel_ro[i] = '1';
          pri[i]=(int.parse(price[i])*int.parse(sel_ro[i]));
          total=pri[0]+pri[1]+pri[2]+pri[3]+pri[4]+pri[5]+pri[6]+pri[7]+pri[8]+pri[9];
          print('pri = ${pri[i]}');
          print("Total = $total");
          print(catagori[i]);
        }
      });
    },
      child: Container(height:120,width: double.infinity,margin: EdgeInsets.only(top: 7,right: 7,bottom: 7),
        color: Colors.transparent,
        child: Stack(
          children:[

            Row(
              children: [
            Checkbox(
              onChanged: (value) {
                setState(() {
                  catagori[i] = value!;
                  if(catagori[i]) {
                    sel_ro[i] = '1';
                    pri[i]=(int.parse(price[i])*int.parse(sel_ro[i]));
                    total=pri[0]+pri[1]+pri[2]+pri[3]+pri[4]+pri[5]+pri[6]+pri[7]+pri[8]+pri[9];
                    print('pri = ${pri[i]}');
                    print("Total = $total");
                  }else{
                    sel_ro[i] = '0';
                    pri[i]=0;
                    print('pri  =  ${pri[i]}');
                    total=pri[0]+pri[1]+pri[2]+pri[3]+pri[4]+pri[5]+pri[6]+pri[7]+pri[8]+pri[9];

                    print("Total =$total");
                  }
                });
              },
              value: catagori[i],
            ),

            Expanded(
              child: Container(margin: EdgeInsets.only(left: 32,right: 24),
                padding: EdgeInsets.only(left: 50),
                alignment: Alignment.centerLeft,
                child:Column(mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children:[ Expanded(
                        child: Text(
                          "${burger[i]}",
                          style: TextStyle(fontSize: 20, color: Colors.black),
                        ),
                      ),]
                    ),
                    Row(children:[
                      Expanded(child: Text("Price is ${price[i]}",))
                    ]
                    )
                  ],
                ),
                decoration: BoxDecoration(
                    color: Colors.white,
                  borderRadius: BorderRadius.circular(20)
                ),
              ),
            )
          ]
          ),
            Column(mainAxisAlignment: MainAxisAlignment.center,
              children:[ Container(height: 80,width: 80,margin: EdgeInsets.only(left: 42,),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child:  ClipRRect(borderRadius: BorderRadius.circular(50),
                      child: Image.asset('images/${img[i]}',fit: BoxFit.fill,))
              ),
              ]
            ),
            Column(mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(height: 50,width: 50,alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: Color(0xFFD7D2D2) ,
                        borderRadius: BorderRadius.circular(30)
                      ),
                      child: ClipRRect(borderRadius: BorderRadius.circular(30),
                        child: DropdownButton(hint: Text("0"),value: sel_ro[i], onChanged: (value) {

                        },items: [
                          dropdownlist1(0,i),
                          dropdownlist1(1,i),
                          dropdownlist1(2,i),
                          dropdownlist1(3,i),
                          dropdownlist1(4,i),
                        ],),
                      ),
                    ),
                  ],
                ),
              ],
            )
          ]
        ),
      ),
    );
  }


 DropdownMenuItem<String> dropdownlist1(int k,int i){
    return DropdownMenuItem<String>(
        onTap: () {
          setState((){
            if(catagori[i]) {
              sel_ro[i] = items[k];
              pri[i] = (int.parse(price[i]) * int.parse(sel_ro[i]));
              print('pri = ${pri[i]}');
              total =
                  pri[0] + pri[1] + pri[2] + pri[3] + pri[4] + pri[5] + pri[6] +
                      pri[7] + pri[8] + pri[9];
              print(total);
            }

          });
        },child: Text("${items[k]}"),value: items[k]);
  }
}
