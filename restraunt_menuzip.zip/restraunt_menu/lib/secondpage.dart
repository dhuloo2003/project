import 'package:flutter/material.dart';

class secondpage extends StatefulWidget {
  int total;
  secondpage(this.total);



  @override
  State<secondpage> createState() => _secondpageState();
}

class _secondpageState extends State<secondpage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Column(mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
              child: Container(color: Colors.grey,
            alignment: Alignment.bottomCenter,padding: EdgeInsets.only(top: 50),
            child: Column(mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Expanded(child: Image.asset("images/c3.png")),
                Expanded(child: Text("Order Receive",style: TextStyle(fontSize: 28),))
              ],
            ),
          )),
          Expanded(
              child: Container(alignment: Alignment.center,margin: EdgeInsets.all(10),
            child: Column(mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [Text("Bill No :-",style: TextStyle(fontSize: 24),),Spacer(),
                    Text("$billno",style: TextStyle(fontSize: 24),)],
                ),
                Row(
                  children: [Text("Amount :- ",style: TextStyle(fontSize: 24)),Spacer(),
                    Text("$amt",style: TextStyle(fontSize: 24))],
                ),
                Row(
                  children: [Text("GST 18% :- ",style: TextStyle(fontSize: 24)),Spacer(),
                    Text("$gst",style: TextStyle(fontSize: 24))]
                ),
                Divider(),
                Row(
                  children: [Text("Total Bill :- ",style: TextStyle(fontSize: 24)),Spacer(),
                    Text("$netamt",style: TextStyle(fontSize: 24))],
                ),Spacer(),
              ],
            ),
          ))
        ],
      )),
    );
  }
String billno='';
  int amt=0,gst=0,netamt=0;
  @override
  void initState() {
    super.initState();
    amt=widget.total;
    DateTime d=DateTime.now();
    billno="${d.year}${d.month}${d.day}${d.hour}${d.minute}${d.second}${d.millisecond}";
    gst=(amt*18)~/100;
    netamt=amt+gst;
  }
}
