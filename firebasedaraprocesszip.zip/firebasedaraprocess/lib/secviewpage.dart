import 'package:firebase_database/firebase_database.dart';
import 'package:firebasedaraprocess/firstpage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class secviewpage extends StatefulWidget {
  const secviewpage({Key? key}) : super(key: key);

  @override
  State<secviewpage> createState() => _secviewpageState();
}

class _secviewpageState extends State<secviewpage> {
  bool status=false;
  List l=[];
  @override
  void initState() {
    super.initState();
    getdata();

  }
  getdata() async {
    DatabaseReference ref=FirebaseDatabase.instance.ref("Contact Book");
    DatabaseEvent databaseEvent=await ref.once();
    DataSnapshot snapshot=databaseEvent.snapshot;
    print(snapshot.value);

    Map map=snapshot.value as Map;

    map.forEach((key, value) {

      // Map m={"key" : key};
      // m.addAll(value);

      l.add(value);
    });
    setState((){status=true;});

  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(onPressed: () {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
          return firstpage();
        },));
      },child: Icon(Icons.add,color: Colors.black,size: 26),),
      appBar: AppBar(title: Text("View Data"),),
      body:status?
          ListView.builder(
            itemCount: l.length,
            itemBuilder: (context, index) {
              Map m = l[index];

              User user = User.fromJson(m);

            return ListTile(onLongPress: () {
              showDialog( builder: (context) {
                return AlertDialog(
                  title: Text("Are you sure for delete data ?"),
                  actions: [
                    ElevatedButton(onPressed: () async {
                      DatabaseReference ref=FirebaseDatabase.instance.ref("Contact Book").child(user.userid!);
                      await ref.remove();
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                        return secviewpage();
                      },));
                      setState((){});
                    }, child: Text("YES")),
                    ElevatedButton(onPressed: () {
                      Navigator.pop(context);
                    }, child: Text("NO")),
                  ],
                );
              },context: context, );
            },
              title: Text("${user.name}\n${user.contact}"),
              trailing: IconButton(onPressed: () {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
                  return firstpage(map: m);
                },));
              }, icon: Icon(Icons.edit)),
            );
          },):Center(child: CircularProgressIndicator(),)

    );

  }


}


class User {
  String? contact;
  String? name;
  String? userid;

  User({this.contact, this.name, this.userid});

  User.fromJson( json) {
    contact = json['contact'];
    name = json['name'];
    userid = json['userid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['contact'] = this.contact;
    data['name'] = this.name;
    data['userid'] = this.userid;
    return data;
  }
}