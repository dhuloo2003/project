import 'package:firebase_database/firebase_database.dart';
import 'package:firebasedaraprocess/secviewpage.dart';
import 'package:flutter/material.dart';

class firstpage extends StatefulWidget {
  Map? map;
  firstpage({this.map});

  @override
  State<firstpage> createState() => _firstpageState();
}

class _firstpageState extends State<firstpage> {
  TextEditingController tname=TextEditingController();
  TextEditingController tcontact=TextEditingController();

  @override
  void initState() {
    super.initState();
    if(widget.map!=null){
      tname.text=widget.map!['name'];
      tcontact.text=widget.map!['contact'];
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(child: Scaffold(
      appBar: AppBar(
        title: Text("Data process"),
      ),
      body: Column(
        children: [
          TextField(
            controller: tname,
            decoration: InputDecoration(hintText: "Enter Name"),
          ),
          TextField(
            controller: tcontact,maxLength: 10,
            decoration: InputDecoration(hintText: "Enter Contact Number"),
          ),
          ElevatedButton(onPressed: () async {
            FirebaseDatabase database = FirebaseDatabase.instance;
            String name=tname.text;
            String contact=tcontact.text;

            if(widget.map==null){

              DatabaseReference ref = FirebaseDatabase.instance.ref("Contact Book").push();
              String? userid=ref.key;

              Map m={"userid":userid,"name":name,"contact":contact};
              await ref.set(m);
              // await ref.set({
              //   "name": "$name",
              //   "contact": "$contact" ,
              // });


            }
            else{
              String? userid=widget.map!['userid'];
              DatabaseReference ref= FirebaseDatabase.instance.ref("Contact Book").child(userid!);
              Map m={"userid": userid,"name":name,"contact":contact};
              ref.set(m);
            }
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
              return secviewpage();
            },));
          }, child: Text(widget.map==null?"Insert Data":"Update Data")),
          ElevatedButton(onPressed:  () {
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
              return secviewpage();
            },));
          }, child: Text("View Data"))

        ],
      ),
    ), onWillPop: goback);
  }

  Future<bool> goback() {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) {
      return secviewpage();
    },));
    return Future.value();
  }
}
