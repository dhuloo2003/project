package com.example.firebasedaraprocess;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
