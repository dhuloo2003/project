
import 'package:on_audio_query/on_audio_query.dart';

class Model
{
 static List<SongModel> songlist = [];
}