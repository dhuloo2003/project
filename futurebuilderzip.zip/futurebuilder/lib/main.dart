import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(home: demo(),));
}
class demo extends StatefulWidget {
  const demo({Key? key}) : super(key: key);

  @override
  State<demo> createState() => _demoState();
}

class _demoState extends State<demo> {
  Future<List> fun1() async {
    await Future.delayed(Duration(seconds: 3));
    List movie=["1","2","3","4","5","6"];
    return movie;
  }
  Future<List> fun2() async {
    await Future.delayed(Duration(seconds: 3));
    List web=["1","2","3","4","5","6"];
    return web;
  }
  Future<List> fun3() async {
    await Future.delayed(Duration(seconds: 3));
    List serial=["1","2","3","4","5","6"];
    return serial;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    body: SingleChildScrollView(
      child: SafeArea(child: Column(
        children: [
          Container(
            height:150 ,
            margin: EdgeInsets.all(10),
            child:FutureBuilder(future: fun1(),builder: (context, snapshot) {
              if(snapshot.connectionState==ConnectionState.done){
                if(snapshot.hasData){
                  List l=snapshot.data as List;
                  return  ListView.builder(
                    itemCount: l.length,
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return Container(
                        height: 150,width: 100,
                        child: Card(
                          child: Text(l[index]),
                        ),
                      );
                    },);
                }
                else{
                  return Text("No data Found");
                }
              }
              else{
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
            },) ,
          ),

          Container(
            height:150 ,
            margin: EdgeInsets.all(10),
            child: FutureBuilder(future: fun2(),builder: (context, snapshot) {
              if(snapshot.connectionState==ConnectionState.done){
                if(snapshot.hasData){
                  List l=snapshot.data as List;
                  return  ListView.builder(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    itemCount: l.length,
                    itemBuilder: (context, index) {
                      return Container(
                        height: 150,width: 100,
                        child: Card(
                          child: Text(l[index]),
                        ),
                      );
                    },);
                }
                else{
                  return Text("No data Found");
                }
              }
              else{
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
            },),
          ),
          Container(
            height:150 ,
            margin: EdgeInsets.all(10),
            child: FutureBuilder(future: fun3(),builder: (context, snapshot) {
              if(snapshot.connectionState==ConnectionState.done){
                if(snapshot.hasData){
                  List l=snapshot.data as List;
                  return  ListView.builder(
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    itemCount: l.length,
                    itemBuilder: (context, index) {
                      return Container(
                        height: 150,width: 100,
                        child: Card(
                          child: Text(l[index]),
                        ),
                      );
                    },);
                }
                else{
                  return Text("No data Found");
                }
              }
              else{
                return Center(
                  child: CircularProgressIndicator(),
                );
              }
            },),
          ),
        ],
      )),
    ),);
  }
}
